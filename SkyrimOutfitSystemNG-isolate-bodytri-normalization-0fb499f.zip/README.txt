BODYTRI 路径写回隔离诊断 0fb499f（不是修复版）
相较 4d24e90，仅恢复 AttachBodyTri 挂载分支；该分支也可能替换未通过可读性检查的同名根节点条目。对已识别的可读 BODYTRI 不做规范化写回。SOS 显式 ApplyVertexDiff 仍禁用。
退出游戏，仅替换 SKSE/Plugins/OutfitSystemNG.dll，避免双加载。保持 PAD 兼容关闭，灯光设置、起始存档、幻化和操作顺序不变。开启 ExtraLogging；确认 SOS BODYTRI path normalization writes disabled; target attachment enabled.
按原顺序复测 OBody 预设，首次闪退即停止；若连续 20 次未崩即可结束。记录次数及 SOS 日志，有崩溃报告再附。不要覆盖存档。不用复测场景结束或实时跟随。
