场景线程防护测试候选 d026448
基线：已验收发色a708434（包含平滑形变27f4c48），仅加入470cf51的Scene FIFO/Reset代际/游戏线程身份门禁。基础hooking目录与a708434完全一致，没有带入AP未完成调用链修复。不是正式1.5.29，DLL资源版本仍1.5.28.0。

安装：在原mod上覆盖，只保留 SKSE/Plugins/OutfitSystemNG.dll，禁用旧名SkyrimOutfitSystemNG.dll，避免双加载。不要覆盖ini/存档。测试前保留原DLL和存档备份，不要为此清理旧档。

验证：
1. 先确认基础幻化/空幻化显示、SAM或OBody连续形变和发色恢复。
2. 看插件日志 MorphRefresh: task thread X game thread Y: accepted（X应等于Y）；deferred说明工作线程被拒绝且待办保留。只有deferred无accepted、形变不跟随或明显变阶梯也算测试失败，请发回完整同次日志。
3. 复现SexLab场景结束、_sex恢复正常与自动穿衣；记录隐形或CTD是否出现，不要连续强行开关幻化抢救。若崩溃，请发该次crash/SOS/skee/skse四日志。

限制：Main::threadID只检验线程身份，不是装备重建/渲染完成屏障；任务可能持续落worker而延迟，实际流畅性待测。没有证明这次FXSteamSphereSkin机械球渲染坏指针由SOS引起或已修。不能用于宣称AP0.4.3兼容修复，该线另行处理。
