BODYTRI 写入隔离诊断 4d24e90（基于 ca985e2，不是修复版）
相对上一轮只新增关闭 SOS 对 BODYTRI 的挂载及路径写回。保留既有 BODYTRI、基础幻化、第三方形变，主动克隆重放仍关闭。
退出游戏，仅替换 SKSE/Plugins/OutfitSystemNG.dll，避免双加载。保持上一轮 PAD 兼容关闭、灯光设定、存档、带 TRI 的幻化及其他模组不变。开启 ExtraLogging，确认 SOS BODYTRI writes disabled; existing metadata retained.
按相同操作顺序复测 OBody 确认预设。不覆盖存档。报告是否闪退、切换次数以及同次 SOS 日志；有崩溃报告则一并附上。测完换回原 DLL。
