仅下一跳模块取证，不是恢复幻化版本。源码6937aec。
替换现有OutfitSystemNG.dll，禁止同时加载旧名SkyrimOutfitSystemNG.dll。启动到主菜单即可，发回完整SOS日志，新增inline FF25 destination / owner / entry bytes记录。
上个版本已抓到私有FF25跳板，但只记录跳板自身的归属，漏了其内嵌指针目标；本版只补这个信息，不放宽安全门禁，不改变形变发色。
若owner识别出DLL，可另提供该DLL用于离线审计，不需发送整个整合包或存档。
