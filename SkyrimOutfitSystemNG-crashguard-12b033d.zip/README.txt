崩溃防护诊断候选 12b033d（资源版本仍1.5.28.0）
包含已经验收的27f4c48形变和a708434发色恢复。
仅安装SKSE/Plugins/OutfitSystemNG.dll；禁用旧SkyrimOutfitSystemNG.dll，禁止双加载。保留原mod其余文件，不删存档。
此候选拒绝把隐藏钩子从原+302移到+3A8；若原调用被第三方改写则关闭幻化并保留真甲。这是安全降级，不是宣称本环境幻化兼容已修复。
请另一位用户以同一1.5.17旧存档测试：能否读档及稳定进入；查看required host +0x302 call-site contract failed、DIAGNOSTIC ONLY、Illusion display is off日志。将完整同次日志发回，需根据原站点周围字节定位真正改写链。不能为恢复幻化而强行覆盖未知第三方跳转。
DLL SHA256 766f72c933272ced1586db8d48dfcaecdde68eb31bee6318e0590d5a86cc45e7
