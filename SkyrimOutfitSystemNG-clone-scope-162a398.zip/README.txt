场景结束克隆范围隔离候选 162a398
基于a708434验收基线+d026448线程防护，仅将重建后的延迟全角色ApplyBodyMorphs改为现有RequestBake(kRebuilt)。保留33ms观察者、即时克隆重放、发色恢复和Scene FIFO，不动基础hooking，不含未完成AP修复。资源版本仍1.5.28.0，不是正式发布版。

安装：覆盖原mod，只保留SKSE/Plugins/OutfitSystemNG.dll，禁用旧名SkyrimOutfitSystemNG.dll。备份原DLL与存档，不改ini，不清理存档。
测试：先确认基础/空幻化、连续SAM或OBody身形和发色；再复现同一SexLab结束恢复与自动穿衣。日志应有accepted；原重建延迟队列不再产生ApplyBodyMorphs日志，仍可看到re-morphed。若仍隐形/CTD，发同次crash/SOS/skee/skse/SLIFNG日志。

此包是最小范围隔离实验，不证明重复全actor调用就是根因；线程身份及150ms延迟均非装备/渲染完成屏障，未解决第三方并发或节点寿命契约。上一候选d026448实机门禁生效仍CTD。不要将测试未崩一次外推为跨环境修复。
