# 钩子说明（HOOKS）

本文记录所有引擎介入点、代码生成方式、语义与排查方法。改版本时只需要动这里的 ID 表和偏移。

## 0. 单套实现

1.0.1 起所有钩子只有一份实现（`src/cpp/hooking/Hooks.cpp`），SE/AE 的地址差异全部写在 `REL::RelocationID(seID, aeID)` 里，CommonLibSSE-NG 按当前运行时的 Address Library 选表。只有「注入的机器码本身不同」的地方才用 `REL::Module::IsAE()`：`ShimWornFlags` / `CustomSkinPlayer` 的目标寄存器（SE rsi/rdi，AE rbx/r15）与 `FixSkillLeveling` 的 AE 内联路径。

## 1. 基础设施

### 1.1 trampoline

`main.cpp` 在 **kDataLoaded** 才分配 trampoline（不在 `SKSEPlugin_Load` 里，因为通过 SKSE branch pool 提前申请会让 1.5.97 在启动阶段直接终止进程）：

- 用 `REL::Module::get().segment(REL::Segment::textx)` 取 .text 范围，在 ±1 GB 内用 `VirtualQuery` 找 `MEM_FREE` 区域，`VirtualAlloc(MEM_COMMIT|MEM_RESERVE, PAGE_EXECUTE_READWRITE)` 64 KB；
- 通过 `Trampoline::set_trampoline(mem, size, deleter)` 交给一个 `new SKSE::Trampoline("local")`；
- `g_branchTrampoline = &SKSE::GetTrampoline()`（SKSE 默认 trampoline，用于 `write_branch`），`g_localTrampoline` 用于 `allocate(gen)` 存放生成的代码。

**为什么必须自己分配**：`write_5branch` 需要 14 字节跳板，`do_allocate` 空间不足时会 `stl::report_and_fail`，那是 `TerminateProcess`，不是异常，`__try/__except` 抓不住。所以任何 `write_branch` 之前都要确认 trampoline 非空且 `free_size() >= 8`。

### 1.2 安装预检（HookSupport）

每个钩子安装前都走三步，任一步失败只写日志并跳过：

```cpp
if (!Hooking::RequireIds("CustomSkinPlayer", { CustomSkinPlayer_Hook_ID, InventoryChanges_ExecuteVisitorOnWorn })) return;
CustomSkinPlayer_Hook = Hooking::ResolveSite("CustomSkinPlayer", CustomSkinPlayer_Hook_ID, 0x1EF);
if (!CustomSkinPlayer_Hook) return;
```

- `IdExists(REL::ID)`：用 `REL::Offset2ID` 遍历全表建立集合（`REL::ID::address()` 在 ID 缺失时会 `report_and_fail`，不能直接试探）。
- `ResolveSite(name, id, offset)`：站点首字节必须是 `0xE8`（call）、`0xE9`（jmp）或 `0x90`（nop 补丁洞），否则记错误并返回 0。
- 全部成功后 `g_branchTrampoline->write_branch<5>(site, code)`。

## 2. 钩子表

### 2.1 SE 1.5.97 的地址列

| 钩子 | 宿主函数 ID | 偏移 | 被调用函数（ID） |
| --- | --- | --- | --- |
| DontVanillaSkinPlayer | 24232 | +0x302 | TESObjectARMO::ApplyArmorAddon (17392) |
| ShimWornFlags | 24220 | +0x7C | InventoryChanges::GetWornMask (15806) |
| CustomSkinPlayer | 24231 | +0x81 | InventoryChanges::ExecuteVisitorOnWorn (15856) |
| FixEquipConflictCheck | 36979 | +0x97 | BGSBipedObjectForm::TestBodyPartByIndex (14026) |
| FixSkillLeveling | 37589 | +0x52 | BipedAnim::VisitGetWornArmorTypeVisitor (37688) |

### 2.2 AE 1.6.1170+ 的地址列

| 钩子 | 宿主函数 ID | 偏移 | 被调用函数（ID） |
| --- | --- | --- | --- |
| DontVanillaSkinPlayer | 24736 | +0x302 | TESObjectARMO::ApplyArmorAddon (17792) |
| ShimWornFlags | 24724 | +0x80 | InventoryChanges::GetWornMask (16044) |
| CustomSkinPlayer | 24725 | +0x1EF | InventoryChanges::ExecuteVisitorOnWorn (16096) |
| FixEquipConflictCheck | 38004 | +0x97 | BGSBipedObjectForm::TestBodyPartByIndex (14119) |
| FixSkillLeveling | 38627 | +0x373 | BipedAnim::GetActorRaceBodyArmorPtrPtr (15696) |

> AE 侧 CustomSkinPlayer 的宿主是 24725：原版对应的 `24735 + 0x81` 已被编译期内联进 24725，所以偏移要加大到 0x1EF。AE 的 FixSkillLeveling 也不再调用 `VisitGetWornArmorTypeVisitor`，改为 `GetActorRaceBodyArmorPtrPtr`，代码生成与 SE 不同（命中时 `mov r12, 0` 后直接跳到 `+0x7B`）。

## 3. 各钩子语义

### 3.1 DontVanillaSkinPlayer —— 阻止真实护甲贴图

`ShouldOverride(armor, target)`：
1. `ShouldOverrideSkinning(target)` 为假（未启用或该 actor 没指派套装）→ 返回 false，走原版；
2. 收集该 actor 的已穿件，算 `compute_display_set_c`；
3. 当前护甲**不在**幻化集合里 → 返回 true，跳过 `ApplyArmorAddon`。

生成的壳代码：保存 `rcx/rdx/r8/r9` → `mov rdx, r13`（actor）→ `call ShouldOverride` → `test al, al` → 真则直接 `jmp` 回原址 +5，否则 `call ApplyArmorAddon` 后返回。

### 3.2 ShimWornFlags —— 伪造 worn 掩码

`OverrideWornFlags(inventory, target)`：真实掩码由原函数算好后**并上**套装件的槽位掩码。

不并集的后果：引擎认为某槽没穿，后续 `CustomSkinPlayer` 贴上的模型会被上层逻辑清掉，表现为“戴帽子就秃头”。

### 3.3 CustomSkinPlayer —— 把幻化件贴上去

先调用原 `ExecuteVisitorOnWorn`（保持其它 mod 的共钩行为），再 `if ShouldOverrideSkinning(actor) Custom(actor, actorWeightModel)`。

`Custom` 里取 `TESNPC::race` 与 `GetSex() == SEX::kFemale`，对集合中**本人没穿**的件逐件 `ApplyArmorAddon(armor, race, actorWeightModel, isFemale)`。

**诚实还原**（1.4.0 起真正实现）：`ApplyArmorAddon` 会把 `BipedAnim::objects[i].item` 改成幻化件，而后续战斗结算和各种读 biped 的 mod 读的就是这个字段。做法：

1. 贴件前按 `equipped` 建 `wornBySlot[32]`（BOD2 槽位 → 真实护甲）；
2. 每件 `ApplyArmorAddon` 返回后，遍历该件槽掩码，`if (slot.item == 这件幻化件 && wornBySlot[bit]) slot.item = wornBySlot[bit];`
3. 第一人称与第三人称 biped 各做一遍。

只撤销自己刚写入的值（判等 `slot.item == a_applied`），真实穿着的槽不受影响；外观仍由 `addon`/`part`/`partClone` 提供，数值仍来自真实装备。开关是 `[Compatibility] ProceduralArmorDamage`（默认 on，关掉即回到旧行为）。1.0.0–1.3.0 的代码**没有**这一步，只有文档写了它——这是 PAD 不生效的根因，见 §4.2。

### 3.4 FixEquipConflictCheck —— 修复“叠头盔”

原版装备冲突检测遍历已穿件，若幻化集合里有同槽位的件，就会判定冲突并卸掉真实件。本钩子把遍历范围内的候选替换成“真实已穿件”，幻化件不参与比较。

### 3.5 FixSkillLeveling —— 修复技能升级

原版按 biped 上实际贴的护甲类型累加轻/重甲经验。幻化后贴的是幻化件，于是穿重甲练轻甲。本钩子改为按**真实**已穿件（跳过盾牌，`kBody` 双计）统计 `light`/`heavy` 计数。

## 4. 第三方 mod 兼容（零 hook / 零补丁）

**原则**：兼容层不 hook 别人的函数、不改别人的代码段、不读别人的内部结构，只用对方已经对外发布的数据契约。这样对方升级（甚至重编译）后仍然有效，只要契约不变。代码在 `src/cpp/compat/`。

### 4.1 为什么删掉了 Papyrus 重绑

1.0.2 / 1.0.3 曾用 `RE::BSScript::Internal::VirtualMachine::RegisterFunction` 覆盖 `Actor.GetWornForm` 与 `Actor.WornHasKeyword`（每次 kDataLoaded / kNewGame / kPostLoadGame 各注册一次，因为 VM 读档会重建类型表）。实机日志里这两条重绑都成功了，但**用户触发判定的 mod 一次都没有走过 Papyrus 入口**——它们读的是引擎 TESCondition（`ExtraWorn` 标记，条件函数表不在 Address Library）。既然覆盖不到真正的判定路径，1.1.0 把整块功能删除，改为下面两个定点兼容。

### 4.2 Procedural Armor Damage：靠“诚实还原”天然兼容

PAD 1.0.4 的可撕件判定链（逆向 PDB + 反汇编得到，仅用于确认兼容性，代码里不含任何 PAD 内容）：

| 步骤 | PAD 做什么 | 依赖的数据 |
| --- | --- | --- |
| `CollectWorn`（RVA 0x33DF0） | 从**玩家背包**收集 `InventoryEntryData::IsWorn` 的护甲，排除 `Actor::GetSkin`，加上 `ExtraDataList` 里的破损副本 | 真实穿戴状态 |
| `ScanScene`（RVA 0x331C0） | 遍历 `BipedAnim::objects[32]`，只保留 `BIPOBJECT.item` 落在上一步集合里的槽，取 `partClone` 的模型名 + addon formID 作 MeshKey | biped 上的 `item` |
| `Capture` / `TearArticles` | 按 MeshKey 记损伤、删三角面 | — |

**1.4.0 起**本插件在 `CustomSkinPlayer` 里贴完幻化件后，会把**真实护甲写回** `BIPOBJECT.item`（§3.3 的“诚实还原”），因此 PAD 的两个门禁都成立，撕坏的是幻化外观下那件真实护甲。（1.0.0–1.3.0 缺这一步：`item` 留的是幻化件，`ScanScene` 直接跳过整槽，所以 PAD 在幻化外观上完全不生效。）我们唯一做的事是**记录**“哪些幻化件下面没有真实护甲”（PAD 看不到它们）。1.2.0 起这条记录改为**掩码变化时才打一条 INFO**（不再要求开 `ExtraLogging`），并提供了 `Settings → Mod compatibility → Log slot report` 的一键逐槽报告（`Compat::Pad::Diagnose`）。

还有一条容易误判的门禁：Papyrus 的 `TearArmor` 会检查「该护甲在玩家背包里至少有一个副本带 ExtraWorn 标记（真穿着）」，并且要求 actor 是玩家、护甲非空。这条**只作用于脚本调用 `TearArmor`** 的路径，PAD 自己的撕裂走原生 `ScanScene`/`TearArticles`，不经过它——所以幻化件不是被它拦下的，也不需要绕过它。

另外注意 PAD 自己的 “Tracked armors” 页只列**已经产生过损伤记录**的护甲副本（PAD 字符串 `No tracked damage in this save.` / `Each entry is one armor copy...`），列表为空不代表 PAD 没看到装备。

### 4.3 Advanced Nudity Detection：写它对外发布的阵营

AND 4.2.0 的判定结果通过阵营发布（逆向结论）：

| 事实 | 证据 |
| --- | --- |
| `ActorWornHasKeyword`（RVA 0x24B20）/ `PlayerWornHasKeyword`（0x2A070）/ `GetPlayerWornObjectList`（0x260D0）扫真实装备的护甲关键词，随后写 `AND_NudeActorFaction` / `AND_ToplessFaction` / `AND_BottomlessFaction` 等阵营 | 三个函数实现同构：`GetInventory` → `IsWorn` → `As<BGSKeywordForm>` → 虚 `HasKeyword` |
| `GetNude`（RVA 0x3D600，113 字节）就是 `Actor::GetFactionRank(AND 阵营, isPlayer) > 0` | 反汇编 |
| AND 自己的 Papyrus getter 与对话条件都读这份阵营数据 | `AND_ModEventListener.GetNude/GetTopless/GetBottomless` |

所以本插件只做一件事：按当前幻化算出的槽位掩码，用引擎调用 `Actor::AddToFaction`（等同 Papyrus `SetFactionRank`）写这三个阵营的等级。

| 阵营 | 等级 1 的条件 |
| --- | --- |
| `AND_NudeActorFaction` | 掩码不含 `Body(2)` |
| `AND_ToplessFaction` | 掩码不含 `Body(2)` / `ModChestPrimary(16)` / `ModChestSecondary(26)` 中任何一位 |
| `AND_BottomlessFaction` | 掩码不含 `Body(2)` / `ModPelvisPrimary(19)` / `ModPelvisSecondary(22)` / `ModLegRight(23)` / `ModLegLeft(24)` 中任何一位 |

- 阵营按 **EditorID** 解析（`TESForm::LookupByEditorID<TESFaction>`），不按 FormID、不按 RVA → AND 更新后依然有效；找不到时只写一条 warn 并退回原版判定。
- AND 会按自己的节奏重扫真实装备覆盖等级，所以每次换装刷新后立即同步一次，另有输入事件心跳（节流 1 秒，跳回主线程）补写。
- 近似性：只看槽位掩码，不按 AND 的关键词做精判；只写上述三个阵营，不碰 `AND_Showing*` 与 Modesty 系列。
### 4.4 菜单语言检测：只读配置，不是 hook

1.2.0 的中英双语完全建立在菜单框架自己的字体能力上：插件读 `Data/SKSE/Plugins/SKSEMenuFramework.ini` 的 `[Fonts] EnableChinese` / `PrimaryFont`，再检查 `Data/SKSE/Plugins/Fonts/<PrimaryFont>` 是否存在，决定要不要出中文。**不修改框架配置、不注入字体、不碰 ImGui 字体图集**（框架在 DXGI Present 首次初始化时才建字体图集，我们的回调那时已经太晚）。字体缺失就退回英文并写一条 warn。

## 5. 日志与排查

日志文件：`Documents/My Games/<game>/SKSE/SkyrimOutfitSystemNG.log`。

| 日志 | 含义 | 处理 |
| --- | --- | --- |
| `Trampoline ready: N bytes at rva 0x... (N free).` | 私有 trampoline 分配成功 | 正常 |
| `Skinning hooks skipped: no trampoline.` | 分配失败（通常是地址空间被占满） | 关掉其它大型插件或反馈 |
| `<hook>: address library id N is missing for runtime X` | 该运行时没有这个 ID | 升级本插件（改 ID 表） |
| `<hook>: unexpected opcode 0xNN at +0x...` | 站点不是 call/jmp，可能被别的 mod 改过 | 该钩子被跳过，游戏可继续运行 |
| `hook installed at rva 0x...` | 安装成功 | 正常 |
| `Compatibility: Advanced Nudity Detection ... detected; nudity, topless and bottomless ranks now follow the displayed outfit.` | AND 兼容生效 | 正常 |
| `... was found, but its nudity factions are missing` | AND 装了但阵营 EditorID 找不到 | 兼容自动退回原版行为 |
| `PAD compatibility: ... without a real armour underneath` | 该幻化件下面没有真实护甲 | PAD 撕不到，属预期 |
| `Menu: SKSE Menu Framework not found` | 没装菜单框架 | 只是没有 UI，其它功能正常 |

## 6. 版本升级步骤

1. 用 Address Library 查新版本对应 ID；
2. 在 IDA/Ghidra 里找同样的调用点，确认偏移；
3. 只改 `src/cpp/hooking/Hooks.cpp` 顶部的 `REL::RelocationID(seID, aeID)` 与 `SiteOffset(se, ae)` 常量；
4. 若宿主函数结构变化（例如又被内联），按 2.2 的 AE 案例重新定位；
5. 编译后看日志确认五个 `hook installed`。
