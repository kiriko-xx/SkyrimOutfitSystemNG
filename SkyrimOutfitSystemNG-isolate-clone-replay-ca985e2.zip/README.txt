主动克隆重放隔离诊断 ca985e2（对照 b040aaf，不是修复版）

只关闭 SOS 显式 ApplyVertexDiff，保留基础幻化、BODYTRI 处理、场景切换、外部模组形变及线程门禁。主动实时跟随可能缺失，属预期。

退出游戏后只替换包内 SKSE/Plugins/OutfitSystemNG.dll，禁用旧名 SkyrimOutfitSystemNG.dll，不改存档、灯光或其他模组配置。开启 ExtraLogging，确认启动日志出现 SOS ApplyVertexDiff disabled for this diagnostic build。

用同一存档和同一套带 TRI 的幻化，先复现已稳定触发的 RaceMenu 拖滑块 → SAM 调整 → OBody 确认预设。回传 SOS 日志，若闪退再附同次崩溃报告；场景结束恢复幻化与 SLIFNG 膨胀另起一轮，分别报告。不要覆盖测试存档，测完换回原 DLL。
