无输入刷新测试候选 0f2638e
覆盖原模组，仅保留 SKSE/Plugins/OutfitSystemNG.dll，禁用旧名 SkyrimOutfitSystemNG.dll，避免双加载。保留原设置与存档。

复测：场景开始、切换服装配件、场景结束及自动穿衣时，不按 Tab 或打开四向菜单，观察外观是否自行更新；再检查 SLIF 膨胀跟随、RaceMenu/OBody 形变、发色和空幻化。启动时应有 Refresh wakeup: independent timer active。该行只证明计时器启动，不证明队列被游戏线程消费。

本候选只补充独立唤醒，保留游戏线程门禁、不改基础钩子，也不修复 SkyrimSE.exe+131C6F6 崩点。若仍延迟，请记录各动作与实际刷新的时间；若仍崩溃，请发同次 SOS、CrashLogger、skee、SKSE及SLIFNG日志。资源版本仍为1.5.28.0。
