# 交付说明（DELIVERY）

## 1. 交付信息

| 项 | 值 |
| --- | --- |
| 版本 | 1.5.17 |
| 构建时间 | 2026-11-16 |
| 主 DLL | SKSE/Plugins/SkyrimOutfitSystemNG.dll（1,809,408 字节，sha256 60c2601228559135ebafe77c4fd854c7d66264e8d1cb3c410201f0195f56007b） |
| 支持运行时 | Skyrim SE 1.5.97（SKSE64 2.0.20）与 AE 1.6.1130+（含 1.6.1170 / 1.6.1179 / 1.6.640），VR 不支持 |
| 构建链 | VS2022 14.44 + CMake 4.2 + vcpkg（x64-windows-static，baseline ee12231b）+ CommonLibSSE-NG（ng 分支） |
| 前置 | SKSE64 + Address Library；SKSE Menu Framework 3.x 可选（只影响菜单与快速选择窗口） |
| 安装包 | SkyrimOutfitSystemNG-1.5.17.zip（31 个条目 = 30 个文件 + SHA256SUMS.txt） |
| 安装包哈希 | 见包外同名 `.sha256` 文件（包内文档无法写入包自身的哈希）；包内逐文件哈希见 SHA256SUMS.txt，30 条全部复核通过 |

## 2. 包内容

| 路径 | 说明 |
| --- | --- |
| SKSE/Plugins/SkyrimOutfitSystemNG.dll | 插件本体 |
| SKSE/Plugins/SkyrimOutfitSystemSE.ini | 默认配置（缺失时自动使用随包默认值） |
| interface/translations/SkyrimOutfitSystemNG_english.txt | **可编辑翻译文件（英文，248 条，UTF-16LE，29,016 字节）**，见 `docs/I18N.md` |
| interface/translations/SkyrimOutfitSystemNG_chinese.txt | **可编辑翻译文件（中文，248 条，UTF-16LE，21,530 字节）** |
| Scripts/*.pex（**6 个**） | 快捷槽、战斗侦测、自动切换、快捷槽管理、MCM 空壳、**SkyrimOutfitSystemNativeFuncs** |
| Scripts/Source/*.psc（6 个） | 对应源码，其中 SkyrimOutfitSystemNativeFuncs.psc 含 **66** 个原生函数声明 |
| SkyrimOutfitSystem.esp | 原版 ESP（法术 / 战斗侦测 / quest 绑定） |
| interface/translations/skyrimoutfitsystem_english.txt | 翻译 |
| docs/ | 10 篇维护文档（1.4.0 新增 I18N.md） |
| README.md / LICENSE.md | 使用说明与许可 |
| SHA256SUMS.txt | 逐文件哈希 |

包内**不含** SKSE Menu Framework 与任何第三方 mod（前置由用户自行安装；插件在框架缺失时照常加载）。

## 3. 需求对照

| 需求 | 实现 |
| --- | --- |
| 迁移到 CommonLibSSE-NG，兼容 SE + AE 1.6.1170+ | 单套 REL::RelocationID(seID, aeID) 地址表（src/cpp/hooking/Hooks.cpp），运行时由 Address Library 选表 |
| 在原 SkyrimOutfitSystemSE 基础上改造 | 原 C++ 层 / Papyrus 层 / ESP / psc / 翻译全部保留，仅 Rust 数据层等价改写为 src/core |
| 舍弃 MCM，改用 SKSE Menu Framework | MenuUI.cpp（Outfits / Actors / Settings / Quick picker），MCM 脚本改空壳 |
| 1000+ 套装浏览 / 搜索 / 快速定位 / 翻页 | 名字搜索 + 仅收藏 + 分页（5–500/页）+ 双击应用 + 结果签名缓存 |
| 随机换装（可仅收藏） | DIK 组合键（默认 Ctrl+Shift+O），边沿触发；手柄组合键尚未实现（见 §7） |
| 快捷槽脚本支持 >100 页 | 改为原生快速选择窗口（搜索 + 分页），不再用 Papyrus 列表菜单 |
| 针对特定 mod 优化（1.1.0 新方向） | Procedural Armor Damage 与 Advanced Nudity Detection 的**零 hook** 兼容层，见 §4.2 / §4.3 |
| 菜单中英双语（1.2.0） | Settings → Language（auto / en / zh），`[UI] Language`，见 §4.6 |
| 原版 MCM 细节功能全部补齐（1.3.0） | 套装编辑器（四种添加方式 / 冲突确认 / 32 槽策略）、Apply to 目标选择、附近角色添加、快捷槽法术开关；逐控件对照见 `docs/MCM_PARITY.md`、§4.7 |
| 外置可编辑翻译文件（1.4.1 改版） | `Data/interface/translations/SkyrimOutfitSystemNG_<语言>.txt`，**每种语言一个文件**（UTF-16LE，`$英文<TAB>译文`），目录里多一个文件就多一个语言选项；缺失时自动写全量模板；菜单内 Reload，见 `docs/I18N.md` |
| 左侧菜单项也走翻译（1.4.0） | Quick picker / Outfits / Actors / Settings 由 `I18n::Tr` 生成，重启游戏后生效（框架缓存标题） |
| 快速选择窗口可操作化（1.4.0） | 640×800 居中自绘窗口；W/S/↑/↓/手柄十字上下选择、A/D/←/→/十字左右翻页（长按加速）；E/Enter/A 穿上、R/Y 随机、Esc/B 关闭；焦点记忆当前穿着与随机结果；底部 Remove outfit |
| Outfits 列表显示不全（1.4.0） | 行宽随文本撑开 + 横向滚动条 + Settings → Interface 的 List width 持久化 |
| 每页数量持久化（1.4.0） | `[UI] OutfitPageSize` / `QuickPickerPageSize`，两个面板的滑条直接读写 ini |
| PAD 在幻化外观上不生效（1.4.0） | `Custom()` 贴完把 `BIPOBJECT.item` 还原为真实护甲（诚实还原），PAD 的 CollectWorn/ScanScene 才认这些槽，见 §4.10 |
| 快选窗位置固化（1.4.1） | `[UI] QuickPickerX/Y/Width/Height`，拖动结束写回 ini，重启后回到原位，见 §4.12 |
| v4 老存档槽位策略错认（1.4.1） | `LegacySave` 解析 `OBSOLETE_slot_policy`(7) / `OBSOLETE_slot_policies`(6) 数字策略并先重置为原版初始态，见 §4.13 |
| 原版 JSON 导入导出（1.4.1） | `OutfitSystemData.json` 按原版 protobuf JSON 结构（lowerCamelCase）读写；Papyrus 两个函数 + 菜单 Settings → Outfit data 两个按钮，见 §4.14 |
| 补齐界面文案翻译（1.4.1） | 词典 153 → 224 条：12 条策略文案（含“需要已装备”/“始终使用套装”）、32 条槽位名、导入导出与错误提示、拼接前缀，见 §4.15 |
| 维护文档 + 编译产物 | 本文 + 9 篇文档 + 可安装包 |
| 快速选择窗口不居中/不记忆/ini 无效、“Debug”标题（1.4.2） | 不再用 `GetCurrentWindow` 判断，独立窗口永远自绘；`ImGuiCond_Always` 套用 ini 矩形；可选 ImGui 符号逐项绑定 —— §4.16 |
| JSON 策略被认成“从不显示任何东西”（1.4.2） | `NormalizePolicyCode()` 认四字符码 / 翻译键 / 中英标签（含新旧“套装/幻化”措辞）—— §4.17 |
| 槽位文案带编号、中文“套装”→“幻化”（1.4.2） | `头部（槽位 0）` …；7 条策略文案改“幻化” —— §4.18 |
| 快选长按太迟钝（1.4.2） | 首次延迟 0.22 s、最小间隔 0.030 s —— §4.16 |
| 槽位号应是 30–61 而非 0–31（1.4.3） | `kDisplaySlotOffset = 30`，并按用户表重写 32 个槽位名 —— §4.19 |
| JSON 导入导出仍错、要按原版结构（1.4.3） | `slotPolicy/slotPolicies` 读写都用原版数字枚举，导入兼容数字/四字符码/翻译键/标签 —— §4.20 |
| Outfits 删除按钮点了没反应（1.4.4） | 原先只把名字存进 `g_pendingDelete` 没人消费；现在有关闭确认条、`delete_outfit()` 真正执行、日志与外观刷新 —— §4.21 |
| 槽位列表/逐槽策略无横向滚动，长名挡住（1.4.4） | 三处子窗口加 `ImGuiWindowFlags_HorizontalScrollbar`，行宽按 `CalcTextSize` 撑开，策略下拉固定宽度 —— §4.22 |
| 默认日志太吵（1.4.4） | 65 条诊断日志降为 `debug`，只在 Settings 勾选 Verbose logging（`[Debug] ExtraLogging=true`）后输出；info 只保留生命周期与用户主动操作 —— §4.23 |
| 地点/状态自动切换改原生（1.4.4） | 新增 `AutoSwitch`：地点变化 / 快速旅行事件 + 输入心跳 2 秒兜底；Papyrus 触发器改为空实现 —— §4.24 |
| 状态套装新增 `<随机>`（1.4.4） | 13 个状态的下拉在 `<继承>` 之后多一项 `<随机>`；进入该状态随机抽一套，同状态不重抽 —— §4.25 |
| Outfits 列表按钮点不中、光标先选中条目（1.5.0） | Selectable 只占名字区，按钮从独立 x 坐标开始，不再重叠；Wear / 星标 / Delete 都能直接点 —— §4.26 |
| 快选窗口手柄出现两个光标，按 A 同时换装和取消幻化（1.5.0） | 独立窗口加 `NoNavInputs` + `NoNavFocus`，框架不再移动第二焦点；窗口自己的键位处理不变 —— §4.27 |
| 切换幻化时自动重置 SMP，且只重置对应角色（1.5.0） | `[Compatibility] AutoResetSMP`；`DynamicHDT.ResetPhysics(actor, false)` 逐角色 soft reload，不是全局 reset —— §4.28 |
| SexLab / OStim 场景自动换 `_sex` 套装（1.5.0） | `[Compatibility] SceneOutfitSwitching`；场景开始查“当前套装名 + _sex”，已带后缀则不变、找不到则保持；场景结束恢复 —— §4.29 |
| 9 小时无人值守自查 bug / 优化性能（1.5.1） | 菜单 revision 缓存、Outfit 槽位/策略缓存、护甲搜索缓存、短锁、设置保存节流；修复列表不刷新、页码越界、热键 latch、快选跨线程刷新等问题 —— §4.30 |
| 继续无人值守自查 / 性能优化（1.5.2） | 输入线程只排队、AutoSwitch/热键回主线程；菜单空指针防护与 revision；场景重叠；守卫栈化、搜索零分配、列表复用、编辑器 500ms 缓存 —— §4.31 |
| 快速选择窗口加 X 键取消幻化（1.5.7） | 键盘 X / 手柄 X 与 Remove outfit 按钮调用同一个 `QuickRemoveOutfit()`，文本输入时不响应 —— §4.35 |
| 带 .tri 的幻化装备不实时刷新（1.5.7） | `MorphRefresh` 轮询 RaceMenu BodyMorph 签名，变化时清空幻化槽并重建 partClone，再延迟 `ApplyBodyMorphs` —— §4.36 |
| 套装编辑器身体槽位“移除”按钮无反应（1.5.8） | 确认条从编辑器顶部改到被点击行内，长名称按钮按可视宽度 clamp，删除成功写 info 日志 —— §4.37 |
| OBody 换身形后只有上衣刷新、裤子等幻化件穿模（1.5.9） | 强制重建范围从 applySet 扩大到整个 displaySet 的并集；真实穿戴但属于显示集的件也清槽重贴 —— §4.38 |
| OBody 换预设后幻化仍不刷新、且环境没有 RaceMenu（1.5.10） | `MorphRefresh` 增加 OBody 插件 API 后端：轮询 `GetPresetAssignedToActor` 预设名签名，变化时 OBody-only 先 `ApplyOBodyMorphsToActor` 再强制重建 displaySet —— §4.39 |
| OBody 换预设后其余幻化件仍不刷新、穿模（1.5.12） | 500 ms 延迟二次重建（等 OBody 稳定）+ OBody 后端重放整套 morph + RaceMenu 接口每 2 秒重试（最多 30 次） —— §4.41 |
| 手动重穿当前套装（Z / 快选窗 E）不刷新幻化（1.5.14） | revision 变化后 2 秒内全量重建（ClearSlots + 重贴 displaySet） —— §4.42 |
| OBody 落定晚于重建、仍穿模（1.5.14） | 400 ms / 1400 ms 两段延迟重建，强制窗口 4 秒 —— §4.42 |
| 幻化循环闪出原版装备且卡顿（1.5.15） | 两阶段合并进同一主线程任务，中间不渲染任何一帧；Z 键直接走循环 —— §4.44 |
| SLIF NG 膨胀后幻化不跟随、穿模（1.5.17） | 修 skee 取接口（命名失败后无名广播重试）+ 新增 SLIF NG 直连查询后端（读 4 个规范膨胀键的 applied 值并入签名）+ 签名静置 250 ms 才重建 —— §4.46 |
| 幻化栏要能复制/粘贴整套预设（1.5.16） | Copy 把选中套装的名称 / 部件 / 基础策略 / 32 槽覆盖写成原版 JSON 进剪贴板；Paste 读剪贴板，重名自动 `_copy`，创建完左侧列表自动选中并滚动到该条 —— §4.45 |

## 4. 本版变更

### 4.1 移除感知层（Perception）

1.0.2 曾重绑 Papyrus 的 `Actor.GetWornForm` / `Actor.WornHasKeyword`。实机日志（1.0.2 与 1.0.3 两次）里**一次都没有出现** `Perception: GetWornForm(...)` 行，说明触发判定的 mod 走的是引擎条件而非 Papyrus 入口；而引擎条件读真实装备的 `ExtraWorn` 标记（TESCondition 函数表不在 Address Library），无法安全改写。既然覆盖不到真实的判定路径，本版按用户要求**整体删除**感知功能：

- 删除 `src/cpp/Perception.cpp`、`src/cpp/include/Perception.h`；
- Papyrus 端删除 `IsPerceptionEnabled` / `SetPerceptionEnabled` / `GetPerceivedArmor`，注册名 69 → **66**；
- ini 删除 `[Perception]` 段与 `[Debug] InstallPerception`。

替代做法是对用户实际在用的两个 mod 做**数据级**兼容（§4.2、§4.3）。

### 4.2 Procedural Armor Damage 兼容（零补丁）

PAD 的可撕件判定链（逆向 PAD 1.0.4 得到，见 `docs/HOOKS.md` §7）：

1. `CollectWorn`：从**玩家背包**取 `InventoryEntryData::IsWorn` 的护甲（排除 skin），加上 `ExtraDataList` 的破损副本；
2. `ScanScene`：遍历 `BipedAnim::objects[32]`，只保留 `BIPOBJECT.item` 落在第 1 步集合里的槽，再用 `partClone` 的模型名 + addon formID 组成 MeshKey，收集三角面；
3. `Capture/TearArticles`：按 MeshKey 记录损伤、删三角形。

**1.4.0 之前这里有个真实缺陷**：`Custom()` 直接调 `ApplyArmorAddon(幻化件, …)`，引擎会把该槽的 `BIPOBJECT.item` 换成**幻化件本身**，于是第 1 步的集合里没有它、第 2 步就整槽跳过 —— 幻化外观永远撕不到。旧文档写着“会如实写回”，但代码里并没有这一步（1.0.0–1.3.0 都没有），这是 PAD 失效的根因。

1.4.0 起 `Custom()` 在每次贴图后做**诚实还原**（`Hooking::CustomSkinPlayer::RestoreRealItems`）：贴之前先按已穿装备建 `wornBySlot[32]`，贴完只把“被自己改写成幻化件”的槽 `item` 换回真实护甲，`addon/part/partClone` 保持幻化件 → 外观不变，但 PAD 的第 1 步照常成立、第 2 步门禁照常通过，撕坏的是幻化外观下那件真实护甲的模型（损伤记在真实护甲上，与“数值仍按真实护甲”一致）。开关：`[Compatibility] ProceduralArmorDamage`（默认 on）。

> 关于用户问的“背包里至少一个副本带 ExtraWorn（真穿着）”：那是 PAD **Papyrus 脚本 `TearArmor`** 的三道门禁之一，只作用于脚本调用路径；PAD 自己的损伤是原生 `ScanScene`/`TearArticles` 走的，不查这一条。所以需要修的不是绕过门禁，而是让 `item` 别被替换。

不需要、也没有对本插件或 PAD 打任何补丁。唯一缺口：**幻化件盖在完全没有真实护甲的槽位时**，该槽 `item == nullptr`，PAD 根本看不到它；`[Debug] ExtraLogging` 会在每次换装后列出这些件：

```
PAD compatibility: 囚犯 shows 'Iron Helmet' over slot mask 0x1 without a real armour underneath; Procedural Armor Damage cannot damage that piece.
```

### 4.3 Advanced Nudity Detection 兼容（写阵营，不碰代码）

AND 4.2.0 的判定结果通过阵营对外发布（逆向结论）：

- `ActorWornHasKeyword` / `PlayerWornHasKeyword` / `GetPlayerWornObjectList` 扫真实装备的护甲关键词，`Finalize` 写 `AND_NudeActorFaction` / `AND_ToplessFaction` / `AND_BottomlessFaction` 等阵营；
- `GetNude`（RVA 0x3D600）内部就是 `Actor::GetFactionRank(AND 阵营, isPlayer) > 0`；
- 因此**阵营等级就是 AND 对外的公开接口**：AND 自己的 Papyrus getter、对话条件、依赖它的其它 mod（OSR/OSL Aroused 一类）全部读这一份数据。

所以本版按幻化后的覆盖情况写这三个阵营（1 = 裸体 / 上身空 / 下身空，0 = 有遮蔽）：

| 判定 | 视为有遮蔽的槽位（bits） |
| --- | --- |
| topless | `Body(2)`、`ModChestPrimary(16)`、`ModChestSecondary(26)` |
| bottomless | `Body(2)`、`ModPelvisPrimary(19)`、`ModPelvisSecondary(22)`、`ModLegRight(23)`、`ModLegLeft(24)` |
| nude | `Body(2)` |

- 阵营按 **EditorID** 解析（`AND_NudeActorFaction` 等），不是按 FormID 或地址 → AND 升级只要不改 EditorID 就仍然有效；解析不到时只写一条 warn，判定退回原版行为。
- **不使用 hook / 入口补丁 / thunk**：不读 AND 的内部函数，也不改它的代码段，只调用引擎的 `Actor::AddToFaction`（等同于 Papyrus `SetFactionRank`）。
- 防漂移：AND 自己会在装备事件与游戏时间 tick 重扫真实装备并覆盖等级，所以 ① 每次幻化刷新后立即同步；② 另有输入事件心跳（节流 1 秒，切回主线程）补写一次。
- 近似性：只看槽位掩码，不按 AND 的关键词（curtain / top / bottom / bra / underwear）精判，混搭护甲可能被判成“有穿”。

### 4.4 兼容层结构

```
src/cpp/compat/
  DisplaySet.{h,cpp}   按当前幻化算出显示集（替代原 Perception 的计算部分）
  ModuleInfo.{h,cpp}   模块路径与文件版本（GetFileVersionInfo）
  PadCompat.{h,cpp}    PAD：检测、状态、诊断日志（不改 PAD 任何东西）
  AndCompat.{h,cpp}    AND：阵营解析、覆盖判定、写阵营等级
  ModCompat.{h,cpp}    统一入口 Install()/Reload()/Tick()/OnOutfitApplied()/GetStatus()
```

菜单 Settings 页新增 “Mod compatibility” 段，逐项显示 `not installed` / `detected (nudity factions follow the outfit)` / `detected, its nudity factions were not found` 等状态；ini `[Compatibility]` 段两个开关默认开启。

### 4.5 PAD 槽位诊断（1.2.0 新增）

实机反馈“挨打时幻化衣服没有变化、PAD 的 Tracked armors 列表是空的”。两条独立事实：

1. **Tracked armors 只列“已经产生过损伤记录”的护甲副本**（PAD 字符串：`No tracked damage in this save.`、`Each entry is one armor copy...`）。列表为空只说明还没撕过，不代表 PAD 没看到装备。
2. **PAD 只能撕“背包里真实穿着且有 ExtraWorn 标记”的护甲**。它的 Papyrus API `ArmorTear.TearArmor` 反汇编后同样有这条门禁（找不到带 ExtraWorn 的副本就返回 -1），所以**不能用 PAD 的 API 让幻化件被撕**——幻化件不在背包里。

因此本版不加补丁，而是让用户能自证：

- Settings → Mod compatibility → **Log slot report** 按钮 → `Compat::Pad::Diagnose(player)`：先逐条列出真实穿着的护甲，再逐槽输出 `PAD slot report: slot  N (0xM) shown 'X' | real 'Y'`；`real '<none>'` 即 PAD 摸不到的槽位。
- 每次换装刷新后，若幻化覆盖了没有真实护甲打底的槽位，按 actor 记录掩码并**只在变化时**打一条 INFO：`PAD compatibility: <actor> shows pieces over slot mask 0x... with no real armour underneath...`。
- 有真实护甲打底的槽位行为不变：PAD 撕的是画出来的那层 mesh，损伤记在真实护甲上。

### 4.6 菜单中英双语（1.2.0 新增）

- 新模块 `src/cpp/I18n.{h,cpp}`：`Lang{Auto,English,Chinese}`、`Tr`（文本）/ `TrId`（控件标签，返回 `中文###English` 让 ImGui 用英文做 id）、`ChineseAvailable`、`Status`。
- 翻译挂在 `src/cpp/include/ImGuiApi.h` 的 `IG::` 包装层，菜单代码保持英文字面量；词典在 `I18n.cpp` 的 `kDictionary`（约 85 条，含 13 个状态名）。
- 字形由菜单框架决定：读 `Data/SKSE/Plugins/SKSEMenuFramework.ini` 的 `[Fonts] EnableChinese` / `PrimaryFont`（默认 `CN.ttf`），并检查 `Data/SKSE/Plugins/Fonts/<PrimaryFont>` 是否存在。缺字体时保持英文并写一条 warn（`Language: Chinese was requested but ... no CJK font loaded`），不画方块、不注入字体、不 hook。
- 配置：`[UI] Language = auto | en | zh`，菜单里改动即时 `Settings::Save()` + `I18n::Refresh()`。

### 4.7 原版 MCM 功能补齐（1.3.0 新增）

原版 `SkyOutSysMCM.psc`（1,099 行、22 个控件家族）在 1.2.0 的 SMF 菜单里只覆盖了套装列表与角色列表。本版逐控件补齐，并把对照关系写成 `docs/MCM_PARITY.md`：

- **套装编辑器**（原版 `ShowOutfitEditor` 整块）：新模块 `src/cpp/MenuOutfitEditor.cpp`，从背包 / 当前穿戴 / 十六进制 FormID / 全护甲表搜索添加护甲（跳过模板护甲与不可玩条目，结果上限 400 条）；槽位冲突时内联确认「替换冲突件 / 取消」（`Outfit::conflicts_with` + 按槽掩码交集移除）；槽位清单按槽掩码展开并带 `Remove` 确认；Base policy + 32 槽逐槽策略 + `Reset all policies to the defaults`。
- **Apply to 目标选择**（原版 `OPT_SelectActorSelection`）：Outfits 页工具条下拉，列表 Wear/双击、编辑器 Wear/Take off 都作用于所选角色；当前穿戴该套装的角色名带 `* ` 前缀（原版 ActiveMark）。
- **Add a nearby actor...**（原版 `OPT_AddActorSelection`）：同 cell、未死亡、FormID 允许的 NPC。
- **快捷槽法术开关**（原版 `OPT_QuickslotsEnabled`）：原版通过 `SkyOutSysQuickslotManager` quest 脚本加/去法术，本版改成原生 `Features::ApplyQuickslotSpell()`（EditorID → `SkyrimOutfitSystem.esp:0x000182F` 回退），在 `kDataLoaded` / `kNewGame` / `kPostLoadGame` 同步，状态写入 `[General] QuickslotsEnabled`。
- **删除/移除确认**：套装删除与角色移除改为内联确认条（SMF 无弹窗 API）；新建/改名按 `GetOutfitNameMaxLength()` 在界面层校验并常显上限。
- **中文词条**：I18n 词典 85 → 135 条，覆盖编辑器、Apply to、确认条与版本行。

已知差异（有意为之）：没有右键上下文菜单、没有 MCM 的 InfoText 面板、没有逐项 Restore defaults、快捷槽改为原生窗口、Export 只含套装与角色分配。

`SkyOutSysMCM.psc` 保持空壳，但补回了原版对外暴露的 `GetModVersion()` / `GetVersion()` / `GetQuickslotManager()` 三个接口，第三方脚本的旧调用不会失效（pex 703 → 991 字节）。

### 4.8 外置可编辑翻译文件（1.4.0 新增，文件布局已被 1.4.1 的 §4.15 取代）

界面文本不再只存在 DLL 里。1.4.0 时读 `Data/SKSE/Plugins/SkyrimOutfitSystemNG_i18n.txt`（单文件 `[en]`/`[zh]` 两段）；**1.4.1 起改为 `Data/interface/translations` 下每语言一份文件，见 §4.15**，旧文件不再被读取。下面保留 1.4.0 的格式说明只作历史参考：

```ini
# 说明行
[en]
Wear=Wear
[zh]
Wear=穿戴
```

- 键是**英文原文**（与 `I18n::Tr` 的入参逐字符一致），值是译文；只写想改的行即可，缺的行回退内置词典（中文）或原样（英文）。
- 文件不存在时自动写出全量模板（153 条 × 2 段），**已存在的文件永不覆盖**。
- 支持 `\n`、`\t`、`\\` 转义；`#` 与 `;` 起头是注释；同一段里重复键后者生效。
- Settings → Language → **Reload the language file** 立即重读，无需重启；左侧树节点标题由菜单框架缓存，**要重启游戏**才更新（界面有提示）。
- 加第三种语言：把 `[en]` 段整段翻成目标语言，`[UI] Language = en`。
- 覆盖范围：菜单文案、左侧树节点、HUD 提示；不覆盖日志、Papyrus 函数名、ini 键名。细则见 `docs/I18N.md`。

### 4.9 快速选择窗口与列表可操作性（1.4.0 新增）

- **窗口不再是隐式 Debug 窗**：SMF 的 `Renderer::RenderWindows()` 只调 `window->Render()`，自己不做 `Begin/End`。此前 `RenderQuickPicker` 没有 `Begin/End`，实际画在 ImGui 的默认调试窗上（所以“尺寸太小、不居中”）。现在用它导出的 `igBegin/igEnd` 自绘窗口，`SetNextWindowSize(640×800, FirstUseEver)` + `SetNextWindowPos(视口中心, FirstUseEver, pivot 0.5)`，位置/尺寸由用户拖动后记忆。
- **键盘与手柄**：SMF 打开任一窗口时会把游戏输入置空并 `io.AddKeyEvent` 喂给 ImGui，所以这里统一查 ImGui 键：`W`/`↑`/`GamepadDpadUp` 上移，`S`/`↓`/`DpadDown` 下移，`A`/`←`/`DpadLeft` 上一页，`D`/`→`/`DpadRight` 下一页，`E`/`Enter`/`GamepadFaceDown` 穿上，`R`/`GamepadFaceUp` 随机，`Esc`/`GamepadFaceRight` 关闭。自写重复器：首次立即触发，按住 0.4 s 后连续、每 0.045 s 一次（越按越快）。
- **焦点记忆**：焦点是全局下标。打开窗口时定位到玩家当前套装；随机后定位到抽中的那套并滚到可见；翻页按整页移动并夹紧。搜索框有焦点时（`IsAnyItemActive`）只有 `Esc` 生效，避免打字触发换装。
- **取消幻化**：底部 `Remove outfit` = `set_outfit_c("", playerId)` + 刷新，HUD 回 `Outfit removed.`，角色露出真实护甲。
- **每页数量与列表宽度**：`[UI] OutfitPageSize`（默认 50）、`QuickPickerPageSize`（默认 20）、`OutfitListWidth`（默认 470），两个面板的滑条直接读改并 `Settings::Save()`。
- 依赖 14 个可选 `ig*` 导出（窗口/按键/尺寸/滚动）。SMF 版本太旧缺其中任何一个时，`ImGuiApi` 只记一条 warn，菜单其余部分照常工作，快速选择窗退化为普通窗口（无键盘导航）。

### 4.10 PAD 诚实还原的实现与开关（1.4.0 修复）

`src/cpp/hooking/Patches.cpp`：

1. `Custom()` 在贴图前用已穿装备建 `std::array<const RE::TESForm*, 32> wornBySlot{}`（按每件护甲槽掩码填位）；
2. 逐件 `ApplyArmorAddon(armor, race, actorWeightModel, isFemale)`；
3. 立即 `RestoreRealItems(actor, armor, wornBySlot)`：第一/第三人称两份 `BipedAnim` 都遍历，`if (slot.item == armor && wornBySlot[bit]) slot.item = wornBySlot[bit];` —— 只撤销自己写进去的 item，真实穿着的槽一个字节都不动。

开关 `[Compatibility] ProceduralArmorDamage = on|off`（默认 on）。设 off 可做对照：同样的操作幻化外观不再可撕，即证明这条路就是修复点。仍然撕不到的只有“完全没有真实护甲打底”的槽（裸槽贴裙子），日志会给出槽掩码。

### 4.11 前情（1.0.1–1.0.3 已修，此处仅备查）

- 载入存档无限载入：`OutfitServiceReadGuard/WriteGuard` 只有构造加锁、析构漏了解锁（照抄 Rust Drop 语义），递归互斥锁被主线程永久持有 → 渲染线程在幻化钩子里阻塞。
- 两套平行钩子实现合并为单套 REL::RelocationID 表；旧 co-save（protobuf v4/v5/v6）在读档时迁移为 JSON v7。
- 缺 `SkyrimOutfitSystemNativeFuncs.pex` 导致 63 个原生函数全部不绑定（日志特征：`Cannot open store for class` + `could find no matching static function`）。
- 法术 “Change Outfit” 的随机行为改由 `IsQuickSlotRandom()` 读 ini（ESP 的 VMAD 里 `RandomOnCast=True` 改不动 psc 默认值）。

### 4.12 快速选择窗口位置/尺寸固化（1.4.1）

- 原实现只有 `ImGuiCond_FirstUseEver` + 居中，而 SKSE Menu Framework 不保存 ImGui 窗口状态，进程结束即忘；插件侧也没有存过任何坐标。
- `Settings` 新增 `[UI] QuickPickerX / QuickPickerY / QuickPickerWidth / QuickPickerHeight`（默认 `-1 / -1 / 640 / 800`，`-1` 表示居中）。
- 每帧在 `BeginWindow`/`EndWindow` 之间用 `igGetWindowPos` / `igGetWindowSize` 读实际矩形；变化后置脏，**0.75 秒无变化**才写 ini（拖拽时不会每帧写盘），窗口关闭时立刻写盘。
- 两个符号是**可选绑定**：菜单框架没导出它们时只退化成“每次居中”，其余功能照常（日志有一行 warn）。

### 4.13 v4 老存档槽位策略错认（1.4.1）

- 现象：从老存档迁移到 v7 后，原本“需要已装备（槽位有装备时才显示套装）”= `XXXO` 变成了“始终使用套装”= `XXOO`。
- 根因：v4 的策略是数字字段（`Outfit.OBSOLETE_slot_policy = 7`、`OBSOLETE_slot_policies = 6`），v5 起才是字符串（9/10）；`LegacySave.cpp` 只解析字符串版，并把套用整段放在 `if (a_version >= 5)` 之下。结果 v4 一个策略都没套上，留下构造函数默认的 `blanket = XXOO` + 盾牌槽 `XEXO`。
- 修法：补 `case 6` / `case 7`（`map<uint32,uint32>`、`uint32`，`repeated uint32` 的 packed 与单值都读）；套用前先把 32 槽清成“继承”、blanket 清成 `XXXX`（= 原版 `from_proto_data` 的初始态），再按原版顺序套字符串策略 → 数字策略；不再看版本号。
- `Policy::FromInt` 映射逐条对齐原版 `Policy::from_int`，`>=128` 视为 `CustomPolicy%03d`。
- 验证点：日志 `Loaded N outfits ... from a legacy co-save`；进游戏看套装编辑器里 policy 文案是否与老存档一致。已迁移过一次且被写成 `XXOO` 的存档，重新导入旧 co-save 即可修正。

### 4.14 原版 `OutfitSystemData.json` 导入导出（1.4.1）

- 路径与原版相同：`Data\SKSE\Plugins\OutfitSystemData.json`。
- 结构按 protobuf JSON 映射（`protobuf_json_mapping::print_to_string` 默认选项）：lowerCamelCase、默认值字段省略、map 键是字符串、uint 是数字。示例：

```json
{
  "enabled": true,
  "outfits": [
    {
      "name": "Mage",
      "isFavorite": true,
      "armors": [ { "rawFormId": 123456, "localFormId": 1234, "modName": "Skyrim.esm" } ],
      "slotPolicy": "XXXO",
      "slotPolicies": { "9": "XEXO" }
    }
  ],
  "actorOutfitAssignments": {
    "20": { "currentOutfitName": "Mage", "stateBasedAutoSwitchEnabled": true, "stateBasedOutfits": { "12": "Mage" } }
  }
}
```

- 导入端也接受 snake_case 原名、`OBSOLETE_*` 数字策略、以及 `armors` 里直接写 FormID 数字的简化写法。
- 入口：Papyrus `ExportSettings` / `ImportSettings`（HUD 提示走翻译）；SMF 菜单 Settings → **Outfit data** 的两个按钮。导入成功会自动 `CreateRefreshAllArmorsTask()` 刷新全部外观。
- 与 co-save 的关系：co-save 仍是**权威存档**；JSON 只是可读写的交换格式（换存档、备份、批量编辑用）。

### 4.15 界面文案翻译补全（1.4.1）

- 词典 153 → **224** 条。典型缺口：12 条策略文案（`Require equipped (show the outfit only when the slot is worn)` / 需要已装备…、`Always use outfit` / 始终使用套装 …）、32 条槽位名、导入导出与错误提示、`[Unnamed]` 等。
- 拼接式 HUD 提示（`"Outfit: " + name`、`"Slot " + label + " uses " + policy`）改为 `I18n::T(en, zh)` 前缀，中文下整句中文。
- 新增语言 = 在 `Data\interface\translations` 放一个新文件，无需改插件。

### 4.16 快速选择窗口：自己开窗、几何真正生效（1.4.2）

- **根因**：`IG::WindowIsOpen()` 用 `igGetCurrentWindow() != nullptr` 判断“框架已开窗”。ImGui 每帧 `NewFrame()` 都会隐式 `Begin("Debug##Default")` 并把它设为当前窗口，因此这个判断**恒为真** → `standalone=false` → 既不 `SetNextWindowPos/Size` 也不 `Begin`，内容全部画进隐式 Debug 窗口（用户看到的标题 “Debug”），`[UI] QuickPickerX/Y/Width/Height` 一次都没被应用。
- **修法**：`MenuUI.cpp` 用 `g_renderingSection` 标志区分两种入口 —— F1 菜单里的“快速选择”页（`RenderQuickPickerSectionThunk` 置位）复用菜单窗口；`AddWindow` 注册的独立窗口（`RenderQuickPickerThunk`）永远自绘 `Begin/End`。窗口标题带 `###SOSQuickPicker`，换语言不丢窗口状态。
- **强制几何**：每次 `ShowQuickPicker(true)` 置 `g_quickGeometryForce`，下一帧用 `ImGuiCond_Always` 套用 ini 里的矩形（`FirstUseEver` 在同一 ImGui 上下文里只生效一次）。拖动/缩放后 0.75 s 节流写回，关闭时立即写。日志 `Quick picker: opening at x,y with wxh (restored from the ini|centred).`
- **可选符号不再一票否决**：`ImGuiApi` 改成逐符号 `GetProcAddress`，失败只 warn 并打印试过的名字；新增 `WindowPlumbingReady()` 只要求 `Begin/End/SetNextWindowPos/SetNextWindowSize`。`igIsKeyDown_Nil` / `igIsKeyPressed_Bool` / `igSetScrollHereY_Float` 都带备选名。日志 `ImGuiApi: N/M optional helpers resolved in ..., window geometry tracked|not tracked.`
- **长按**：`kRepeatDelay 0.40 → 0.22`、`kRepeatMinInterval 0.045 → 0.030`、`kRepeatAcceleration 0.045 → 0.030`。

### 4.17 OutfitSystemData.json 策略规范化（1.4.2）

- **根因**：策略字段被当作四字符码存取，而文件里可能写的是本地化标签（`需要已装备（槽位有装备时才显示套装）`、`始终使用套装`）。`FindPolicy()` 精确匹配失败 → `compute_display_set_c()` 直接 `continue` → 该槽位“什么都不显示”（用户看到的“从不显示任何东西”）。
- **修法**：`Policy::NormalizePolicyCode()` 接受四字符码、`$SkyOutSys_Desc_EasyPolicyName_XXXX`、英文标签、新旧中文标签（“套装/幻化”两套）、`CustomPolicyNNN`、纯数字（走 `PolicyFromInt`）。导出统一写四字符码（**1.4.3 更正：已改回数字枚举，见 §4.20**）；导入先规范化再落库；认不出只 warn 并回落基础策略。
- **兜底**：`compute_display_set_c()` 未知策略 → 基础策略 → `XXOO`；`slotPolicies` 的值同时接受字符串与数字。

### 4.18 槽位编号与“幻化”措辞（1.4.2）

- 策略编辑器所有槽位名追加编号：中文 `头部（槽位 0）`、英文 `Head (slot 0)`，与 `BIPED_OBJECT` 一一对应。
- 中文 7 条策略文案由“套装”改成“幻化”；旧措辞仍作为导入别名保留，1.4.1 写的 JSON 与语言文件不会失效。

### 4.19 槽位编号改为游戏里的 30–61（1.4.3）

- 内部 BOD2 索引是 0 基：`kHead = 0` … `kFX01 = 31`（`include/RE/B/BipedObjects.h`）。Creation Kit、xEdit 和游戏里给玩家看的编号是同一个槽位 **+30**（头 30、头发 31、身体 32 … 盾牌 39 … FX 61）。
- 1.4.2 直接把内部索引当显示号追加，所以全文都错了 30。1.4.3 在 `src/cpp/MenuOutfitEditor.cpp` 里加 `kDisplaySlotOffset = 30`，`SlotLabelFor()` 输出 `a_index + 30`，显示成 `头部（槽位 30）`、`盾牌（槽位 39）`、`FX（槽位 61）`。
- 同时按用户给的对照表重写 `kSlotLabels[32]` 的中文名：`头发, 短` / `头发, 长` / `项链`（原“护符”）/ `未知 (一般来说是 面部)` … `未知 (一般来说是 其他 2)` / `Decapitate-Head` / `Decapitate` / `FX`。英文列同步（`Unnamed (probably Face)` 等），`src/cpp/I18n.cpp` 词典跟着改（仍 224 条），两份语言文件重新生成。

### 4.20 OutfitSystemData.json 全面对齐原版：策略用数字枚举（1.4.3）

- **文件真实结构**（`兼容参考/OutfitSystemData.json`，530 套、2 个 actor）：`{ "enabled": true, "outfits": [ { "name", "isFavorite", "armors": [ { "rawFormId", "localFormId", "modName" } ], "slotPolicies": { "9": 8 }, "slotPolicy": 2 } ], "actorOutfitAssignments": { "<十进制 FormID>": { "currentOutfitName", "stateBasedAutoSwitchEnabled", "stateBasedOutfits": { "0": "名称" } } } }`。策略是 **protobuf 枚举数字**：2 = `XXXO`（需要已装备）、5 = `XXOO`（始终使用幻化）、8 = `XEXO`（穿透，盾牌默认）。
- **旧实现的错**：1.4.1/1.4.2 用 `FetchString()` 读 `slotPolicy`，遇到数字返回空串 → 基础策略保持默认 `XXXX`（从不显示任何东西）；只有 `slotPolicies` 里零星几个数字槽位是对的。导出则写四字符码字符串，与原版文件格式不一致。
- **现在的行为**：`src/core/OutfitService.cpp` 新增 `FetchPolicyCode()`：数字 → `PolicyFromInt()`（0–11，≥128 → `CustomPolicyNNN`）；字符串 → `NormalizePolicyCode()`（四字符码 / `$SkyOutSys_Desc_EasyPolicyName_*` / 中英文标签，含旧“套装”措辞）。导出用新增的 `PolicyToInt()` 写数字 id，字段顺序、省略默认值的规则都与原版 `protobuf_json_mapping` 一致（`enabled`、`isFavorite`、空 `armors`、`slotPolicy = 0` 都会省略）。
- 导入顺序复刻原版 `from_proto_data()`：先重置 32 槽为 nullopt、基础策略 `XXXX`，再套 `slotPolicies` 数字图，再套 `slotPolicy`，最后才是 `OBSOLETE_*` 兼容字段。

### 4.21 Outfits 删除按钮（1.4.4）

- 根因：`MenuUI.cpp` 的 `Delete` 只执行 `g_pendingDelete = name;`，全文件没有任何地方读取它，所以既不删也不打日志。
- 现在：列表上方出现确认条 `Delete outfit "X"? This also removes it from every actor and state assignment.`；`Delete` 调 `OutfitService::delete_outfit()`（会清掉所有 `current` 与 `stateBased` 引用），成功写 `Outfits: deleted 'X': yes.`，并清空选中/过滤缓存、`CreateRefreshAllArmorsTask()` 让在场角色立刻换回真实护甲；`Cancel` 只关确认条。

### 4.22 套装编辑器横向滚动（1.4.4）

- `##outfiteditor`、`##slotlist`、`##slotpolicies` 三个子窗口都带 `ImGuiWindowFlags_HorizontalScrollbar`。
- 槽位行不再用固定 `SameLine(320)`：行宽 = `CalcTextSize(行文本) + 16`，至少 320，长护甲名会把列宽撑开、按钮跟着右移，可横向拖动查看。
- 基础策略与 32 个逐槽策略的 combo 统一 `SetNextItemWidth(520)`，译文再长也不会顶到右侧。

### 4.23 日志分级（1.4.4）

- 65 条诊断日志（Settings 读取、MenuBridge/ImGuiApi 绑定细节、每个钩子的地址/字节、Hotkeys 注册与触发、兼容层检测、SetStatus/NotifyChanged 等）从 `info` 降为 `debug`。
- 保留在 `info` 的只有：`Skinning hooks applied.`、`Papyrus functions registered.`、`Game event sinks registered.`、`Saved N outfits...`、`Migrating a vN record...`、`vN is loading...`、`Plugin loaded, waiting...`、`Loaded/Imported N outfits...`、`Menu: sections registered...`、`Language: wrote the editable translation files...`、`AutoSwitch: native location...`、`Outfits: deleted...`、`Menu: export/import...`、`PAD slot report...`（用户主动点按钮生成）。
- `[Debug] ExtraLogging=true`（菜单 Settings → Verbose logging）时 spdlog 级别为 `trace`，全部 `debug` 重新可见。

### 4.24 地点/状态自动切换改为原生（1.4.4）

- 1.4.3 及更早：战斗由 `CombatStartSubscription`（C++，`TESCombatEvent`/`TESDeathEvent`）处理；地点靠 `SkyOutSysAutoSwitchTrigger.psc` 的 `OnLocationChange` → `Utility.Wait(10.0)` → `SetOutfitUsingStateForAllConfiguredActors()` + `RefreshArmorForAllConfiguredActors()`，最坏晚 10 秒。
- 1.4.4 新增 `src/cpp/AutoSwitch.{h,cpp}`：`LocationSink`（`TESActorLocationChangeEvent`）与 `FastTravelSink`（`TESFastTravelEndEvent`）注册到 `ScriptEventSourceHolder`；只处理 `should_override()` 且开了状态自动换装的 actor；`NGHotkeys` 的输入 sink 每次事件调 `AutoSwitch::Tick()`（2 秒节流）兜底天气变化/漏事件。
- 去抖：`AutoSwitch` 的 `FormID→state` 缓存 + `ActorAssignments::lastState` 两层，状态没变直接返回；只有变化才 `setOutfitUsingState()` + `refreshArmorFor()`。
- `skyoutsysautoswitchtrigger.psc` 改为空实现（保留 `Scriptname SkyOutSysAutoSwitchTrigger extends ReferenceAlias`），旧存档/ESP 仍能解析；打包的 pex 也换成空实现版本。

### 4.25 状态套装 `<随机>`（1.4.4）

- 数据层：`OutfitService::kRandomStateOutfit = "<random>"` 作为哨兵，允许写进 `stateBasedOutfits`（序列化、co-save、JSON 导入导出都放行）。
- 行为：`set_state_outfit(state, "<random>")` 立即随机抽一套并写 `current`；之后 `set_outfit_using_state` 在 `lastState` 与当前状态相同时不重抽（战斗事件反复触发保持同一套），状态真正变化时才重抽。
- 随机规则：尊重 `RandomOutfit.FavoritesOnly`，默认排除当前正在穿的那套（`_outfits.size() > 1` 时）；收藏过滤后为空则回退全部套装。
- UI：13 个状态的下拉在 `<inherit>` 之后多一项 `<random>`（中文 `<随机>`）；combo 预览直接显示译文。

### 4.26 Outfits 列表按钮被整行 Selectable 抢走点击（1.5.0）

- **现象**：左列表里「Wear（穿上）」几乎点不中；「Delete」也只能偶尔在边缘点中；点击大部分区域只会选中/取消选中条目。删除逻辑本身正常（点中时确实会删）。
- **根因**：行宽 `rowWidth = max(CalcTextSize(label).x + 150, listWidth - 24)`，`Selectable` 使用整个 `rowWidth`；Wear / 星标 / Delete 用 `SameLine(rowWidth - 142 + 8)` 叠在同一个矩形上。ImGui 的 `Selectable` 是整块可点击区域，先吃掉鼠标事件，按钮只剩极小边缘能命中。
- **修法**（`src/cpp/MenuUI.cpp`）：
  ```cpp
  constexpr float kButtonReserve = 150.0f;
  const float textWidth = IG::CalcTextSize(label.c_str()).x + 8.0f;
  const float buttonX = std::max(textWidth + 8.0f, std::max(listWidth - kButtonReserve, 0.0f));
  const float nameWidth = std::max(buttonX - 8.0f, textWidth);
  IG::Selectable(label.c_str(), isSelected, 0, ImVec2(nameWidth, 0.0f));
  IG::SameLine(buttonX);
  ```
- **结果**：名字区与按钮区完全分离；短名字时按钮固定在列表右侧，长名字时按钮跟在文字后面并撑出横向滚动；双击选中、tooltip、收藏/删除确认流程都不变。

### 4.27 快速选择窗口用手柄时出现两个光标（1.5.0）

- **现象**：手柄十字键移动列表时，另一个高亮同时出现在 `Remove outfit` 等控件上；按 A 会先换装、再执行那个按钮（例如取消幻化）。
- **根因**：窗口自己读 `GamepadDpad*` 移动 `g_quickFocus`，但独立窗口只设了 `NoCollapse`，ImGui 默认导航仍在同一窗口里移动另一个控件焦点。
- **修法**：`RenderQuickPicker` 的 flags 改为 `ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoNavInputs | ImGuiWindowFlags_NoNavFocus`。手动 W/S/A/D、方向键、十字键、E/R/Esc 全部保留；SMF 的全局快捷键不受影响。
- **结果**：窗口内只有一个焦点（列表高亮），A 只执行换装，B/Esc 只关闭。

### 4.28 切换幻化时按角色重置 SMP（1.5.0）

- 新配置：`[Compatibility] AutoResetSMP = off`（默认关；设置页 Mod compatibility 勾选 “Reset SMP physics when the outfit changes”）。
- 调用链：`OutfitSystem::refreshArmorFor(actor)` 末尾 → `SOS::SMP::ResetActor(actor)` → `SKSE::GetTaskInterface()->AddTask` → 取 `ActorHandle`、判 `Is3DLoaded()` → `DynamicHDT.ResetPhysics(actor, false)`。
- 只影响目标角色：FSMP 的 `ResetPhysicsImpl` 按 `skeleton->GetUserData()->formID == actor->formID` 找到那一个 skeleton 后 `softReloadMeshes()`，不调用全局 `smp reset`，也不遍历 NPC。
- 兼容性：未装 FSMP / `DynamicHDT` 类型不存在时只写一条 debug 日志并跳过；设置页会显示检测结果。`full=false` 是温和重建，避免整件装备重新加载造成卡顿。
- 日志（debug）：`SMP: Faster HDT-SMP (DynamicHDT) is not installed; the physics reset is skipped.` / `SMP: DynamicHDT.ResetPhysics could not be dispatched for {:08X}.`

### 4.29 SexLab / OStim 场景自动换 `_sex` 套装（1.5.0）

- 新配置：`[Compatibility] SceneOutfitSwitching = off`（默认关；设置页 Mod compatibility 勾选 “Wear <current outfit>_sex during SexLab / OStim scenes”）。
- 事件：`SKSE::GetModCallbackEventSource()` 的 `ModCallbackEvent`；OStim 用 `ostim_start` / `ostim_end`，SexLab 用 `PlayerAnimationStart` / `PlayerAnimationEnd`（只监听 Player 前缀，NPC-only 线程不触发）。
- 开始：当前幻化名为空 → 不变；名称已以 `_sex` 结尾（大小写不敏感）→ 不变；否则 `candidate = 当前名称 + "_sex"`，在 `OutfitService` 里按忽略大小写精确查找；找不到 → 不变；找到 → 记录 `previous/sceneOutfit`，换上并 `refreshArmorFor(player)`。
- 结束：若玩家仍穿着场景套装（忽略大小写比较）→ 恢复 `previous`（空名表示取消幻化）；若玩家中途手动换了别的套装 → 不覆盖玩家选择。
- 日志（debug）：`SceneOutfits: ... scene started; 'A' -> 'A_sex'.` / `SceneOutfits: ... scene ended; 'A' restored.` / 找不到时 `no 'A_sex' outfit for the ... scene; the current outfit is kept.`
- 局限：事件只带线程号，不带参与者列表，因此只对玩家生效；OStim 的 NPC 子线程（`ostim_subthread_*`）不处理。

### 4.30 1.5.1 性能与健壮性审计

- **菜单性能**：OutfitService 增加原子 revision；MenuUI 的套装名与过滤结果按 revision 缓存；Outfit 增加槽位与策略缓存；服装编辑器的完整护甲列表按 TESDataHandler + 护甲数组 size/data 缓存；装备访客改 vector 并 reserve(32)。菜单打开时不再每帧复制全部套装名、不再每次搜索扫描全表。
- **锁范围**：Outfits / Actors / 编辑器先用短读守卫复制快照再绘制，写操作单独短写锁；避免渲染线程的皮肤钩子在菜单打开期间等待整帧。
- **线程安全**：随机数改 thread_local；热键状态改 mutex + atomic；MenuBridge 可用标志与 MenuUI 注册/快选刷新标志改 atomic；快选窗刷新与焦点定位延迟到渲染线程；修复文本框松开后 latch 卡住。
- **健壮性**：装备访客空指针判定、SKSE 任务接口判空、RefreshActor 的 Is3DLoaded 检查、Outfits 页码 clamp、套装名缓冲区 257 字节并在服务层强制 256 字节上限、DisplaySet 使用真实 enabled 状态、InstallHooks=0 真正生效、新游戏重置 enabled=true。
- **文案**：中文“套装”统一改为“幻化”（Policy.cpp 旧别名保留用于历史 JSON）；语言文件重新生成，仍为 233 条。
- **未改的已知限制**：AutoSwitch::Tick 仍由输入事件心跳驱动（2 秒节流），玩家完全静止且天气变化时要等下一次输入才评估；PadCompat 的 g_orphanMask 对已移除 actor 只做小缓存，不清理；Settings::IsGoldenItem 的懒解析依赖 WarmUp，异常路径无锁。

### 4.31 1.5.2 第二轮无人值守审计（线程安全 / 空指针 / 缓存）

- **线程安全**：`AutoSwitch::Tick` 在输入线程仅做 2 秒节流与 `g_tickPending` 排队，`TickOnMainThread` 才遍历 actor、评估状态并刷新；随机换装/快选热键的 `Fire` / `FireQuickPicker` 也改为 `SKSE::GetTaskInterface()->AddTask`。文本输入状态由渲染线程采样、在 `NGHotkeys` 缓存 500ms，输入 sink 不再读 ImGui。
- **Settings 黄金件**：`_goldenResolved` 改 `std::atomic<bool>` + `_goldenMutex`；`WarmUp` / `InvalidateResolvedForms` 加锁，`IsGoldenItem` 只读 atomic 后查集合。
- **空指针防护**：MenuUI 的 Add player 判玩家；TargetName / RenderOneActor / 删除确认 / MenuOutfitEditor 目标名对 `GetDisplayFullName()` 空值兜底。Patches 的 `FixEquipConflictCheck` 判 item/target/ActorEquipManager；战斗/死亡事件判玩家；`RegisterEvents` 判 ScriptEventSourceHolder；`CreateRefreshAllArmorsTask` 判任务接口。
- **缓存正确性**：`OutfitService::check_consistency` 在插入玩家或清理非法 FormID 后递增 revision；删除套装时同时失效快速选择列表与过滤结果；状态自动切换勾选与 13 状态套装修改后调用 `NGFeatures::ApplyCurrentStateOutfit` 立即应用当前状态。
- **界面**：所有菜单页推进 `FlushSettingsIfDue()`，在快选/Outfits 改页大小不必再打开 Settings 才落盘；热键输入框随 ini 值刷新；Page size 范围 5..500，List width 240..1200；删除套装当前帧不再显示旧行。
- **性能**：OutfitService 读写守卫改栈上返回值（去掉皮肤热路径每次 `make_unique`）；DisplaySet 的访客直接写调用方 vector、`ComputeDisplaySet` 复用 `thread_local` 缓冲；名称搜索无分配大小写折叠，仅收藏过滤时才查哈希；Outfits 页复用页内 vector，非当前穿着行不复制 label；编辑器背包/穿戴列表 500ms TTL 缓存；PadCompat 诊断映射上限 512。
- **场景重叠**：SceneOutfits 的 `g_activeSources` 支持 OStim/SexLab 同时开始，同一来源重复 start 忽略，最后一个场景结束才恢复进入前的套装。
- **构建**：version.h / CMake / vcpkg 升 1.5.2；本次因 version.h 触发全量编译，`--parallel 4` 首次报 C1076（页面文件不足），两个 buildtask 改为 `--parallel 1` 后 `BUILD_EXIT=0`、0 error。

### 4.32 1.5.3 第三轮无人值守审计（存档/脚本边界、状态判定、构建）

- **Papyrus 删除/覆盖不刷新**：DeleteOutfit 删除成功后排队刷新；OverwriteOutfit 改走 OutfitService::replace_outfit_armors()（整体替换 + revision 递增）并排队刷新。修复第三方脚本删除/覆盖当前显示套装后幻化残留到下次装备刷新。
- **状态套装漏判**：AutoSwitch、战斗事件、死亡事件的资格判定从只看 should_override()（隐含要求基础套装）改为 enabled && 该角色开启状态切换 && (有基础套装 || 任一状态套装已配置)；战斗/死亡事件同时补 per-actor 的 stateBasedAutoSwitchingEnabled 判定，关闭开关后不会再被战斗事件强行换回状态套装。
- **随机换装**：仅收藏且唯一收藏就是当前套装时，候选为空导致热键无反应；现在回退到全部套装，再回退到允许抽当前套装。
- **坏存档/坏 JSON**：co-save v7 与 OutfitSystemData.json 的字段类型异常原本会抛 nlohmann 异常终止进程；两处加载都加了 try/catch，只记 error 并返回失败。
- **金件读竞争**：_resolvedGolden 改为 shared_ptr 快照 + atomic_load/store，IsGoldenItem() 的渲染线程读路径无锁。
- **构建**：从 target_compile_options 移除 /MP（它会绕过 --parallel 1 再开满核 cl.exe，4.8 GB 页面文件下触发 C1076/C3859）。
- **翻译**：词典去重后 237 条唯一词条（233 + 12 新增中 8 条与旧条目重复，已合并），语言文件按 237 条重生成。
### 4.33 快速选择窗口手柄导航全局失效（1.5.4；结论已被 §4.34 修正）

- **1.5.5 更正**：本节结论不完整。实机确认 SMF 3.9 升级后 1.5.4 原样恢复，主因是旧框架对自定义窗口的 gamepad 处理；NoNavInputs 只是叠加因素。**1.5.6 再更正**：3.18 也已实测正常，3.23 不是分水岭，版本门控已下调到 3.18。
- 现象：1.5.0 起打开过快速选择窗口后，不仅窗口内手柄无反应，SMF 主菜单的十字键/A/B 也全部失效；键盘与鼠标仍正常。
- 根因：快选窗带有 `ImGuiWindowFlags_NoNavInputs`。ImGui 1.90 的 `io.NavActive` 要求当前 `g.NavWindow` 没有 NoNavInputs；快选窗成为 NavWindow 后，整个 ImGui 上下文的 NavActive 被置为 false，SMF 的 GamepadNavigation 随之停止。`NoNavFocus` 只影响 Ctrl+Tab，不是主因。
- 修法：去掉快选窗的 NoNavInputs/NoNavFocus，只保留 NoCollapse；运行期绑定 `igPushItemFlag`/`igPopItemFlag`，在 `RenderQuickPickerBody()` 前后压入 `ImGuiItemFlags_NoNav`（1 << 3），让快选窗内部控件不参与 ImGui 导航但窗口仍是 NavWindow。这样 `io.NavActive` 保持为真，SMF 主菜单手柄恢复；快选窗的 W/S/A/D、十字键、A/B/X/Y 仍由自己的 `IsKeyDown`/`IsKeyPressed` 处理。
- 这两个导出属于可选绑定：缺失时只记 `ImGuiApi: igPushItemFlag/igPopItemFlag are missing ...`，快选窗仍能打开。

### 4.34 快速选择窗口手柄：SMF 3.9 / 3.18 / 3.23（1.5.5–1.5.6）

- 现象：1.5.4 + SKSE Menu Framework 3.9 时，打开快速选择窗口后窗口内与 SMF 主菜单的手柄都无反应；键盘正常。
- 实机确认：**只把 SMF 3.9 升级到 3.18 或 3.23，1.5.4 未改任何代码，手柄全部恢复**。因此主因是 3.9 对自定义 `AddWindow` 窗口的 gamepad 处理，不是幻化钩子；3.23 不是分水岭，3.18 已可用。上游源码核对：3.14.0 引入 `GamepadNavigation` 并修复 gamepad 不可用的回归（提交 8fb2d29）。
- 兼容加固：`MenuBridge::WindowInterface` 显式置 `BlockUserInput = true`；1.5.6 起仅当 `FrameworkVersion() < 3.18`（或取不到）时注册 `RegisterInpoutEvent` 原始回调，快选窗打开时直接读 `RE::ButtonEvent` 的十字键/A/Y/B，渲染线程消费；3.18+ 不注册，避免 `InputEventHandler::Process` 把事件从框架队列中移除。1.5.5 初版阈值原为 3.23，1.5.6 按 3.18 实机结果下调。
- 日志：`Menu: SKSE Menu Framework <版本> (api <n>)`；旧版有 `raw gamepad input enabled ...`；3.18+ 有 `handles gamepad input ...`。

### 4.35 快速选择窗口 X 键取消幻化（1.5.7）

- 需求：快速选择菜单给“取消幻化”分配快捷键 X，键盘也沿用 X。
- 实现：`MenuUI.cpp` 新增 `QuickRemoveOutfit(RE::Actor*)`（清空当前套装、`Features::RefreshActor`、HUD `Outfit removed. / 已取消幻化。`）。键盘 `ImGuiKey_X`，手柄 `ImGuiKey_GamepadFaceLeft`；旧 SMF（<3.18）的 raw 路径用 `RE::BSWin32GamepadDevice::Key::kX` 置 `g_padRemove`。底部 Remove outfit 按钮也改调同一个 helper。
- 文本输入（搜索框等 `IsAnyItemActive`）时不响应 X；底部提示与按钮 tooltip 改为 `X: remove` / `（X）`。

### 4.36 `.tri` 形变实时刷新（1.5.7）

- 现象：幻化件带 `.tri` 形变（OBody、游戏内实时换身形预设等）时，改 morph 滑块或换预设后模型不跟着变，必须重新穿脱套装或先取消幻化。
- 根因：`ApplyArmorAddon` 对同一 `item` 会复用 BipedAnim 里已有槽位，`refreshArmorFor()` 只重跑皮肤钩子，不会重建 `partClone`；旧 clone 的顶点缓冲仍是旧形变。
- 实现：新增 `src/cpp/MorphRefresh.{h,cpp}`，运行期通过 `skee` messaging（0x9E3779B9）取 RaceMenu `BodyMorph` v4+ 接口，250 ms 节流轮询已幻化且 3D 已加载 actor 的 `VisitMorphValues` FNV 签名；变化时开 2 秒强制窗口并 `Features::RefreshActor()`。`Patches.cpp` 的 `Custom` 在窗口内先对幻化槽调用 `BipedAnimAugments::ClearBipedPart`（15496/15661）并清空 `item/addon/part`，再 `ApplyArmorAddon`；1.5.9 起改为按整个 displaySet 的并集清槽并重贴全部显示件。重建后 150 ms 调 `ApplyBodyMorphs(actor, true)` 处理 partClone 延迟挂载。
- 兼容：1.5.10 起没装 RaceMenu 或 BodyMorph < 4 时会尝试 OBody 4.4.0+ 插件 API；两者都没有才停用 `.tri` 刷新，其余功能不受影响；未幻化 actor 不参与轮询。
- 限制：RaceMenu 接口是按 ABI 手写的最小声明（`VisitMorphValues` 槽位 10、`ApplyBodyMorphs` 槽位 13），待实机验证。

### 4.37 身体槽位列表“移除”无反应（1.5.8）

- 现象：在 SMF 幻化栏选中套装后，右侧 Body slots 列表点“移除”没有任何可见反馈；日志只有 trace/debug，没有 Outfit editor 或 Removed 记录。
- 根因：第一次点击只把护甲指针写进 g_pendingRemove，确认条 RenderRemoveConfirmation 固定渲染在编辑器顶部；用户滚到下方的槽位列表时看不到它。另一个叠加因素是按钮 X 用护甲名宽度计算，长名字会把按钮推到子窗口可视区外。
- 修法：删除顶部确认条，改为行内确认——被点击行先显示 Remove ... from the outfit? 提示，同一行出现 Remove / Cancel；确认后才调用 RemoveArmor，取消只清状态。按钮 X 改为按 IG::ContentRegionAvail().x clamp，长名称不会再把它挤出可视区。Invalidate 清空 g_pendingRemoveSlot，切换套装时自动取消上一个套装的确认。
- 日志：删除成功写 info 级别 Outfit editor: removed 'X' from 'Y'.；NotifyChanged 仍打印套装当前件数（debug）。
- 未实机验证：行内确认与按钮位置需要进游戏点一次确认。

### 4.38 OBody 换身形后多件幻化不刷新（1.5.9）

- 现象：幻化套装有 .tri 形变时，在 OBody 换身体预设，32 槽位带身体参照模型的上衣刷新了，但裤子等其他部件仍是旧模型，直接穿模。
- 根因：1.5.7 的强制重建分支只清空并重贴 applySet（显示集中不属于实际穿戴的幻化件）。displaySet 里同时有真实穿戴的护甲时，这些护甲由引擎应用、被 Custom 的 applySet 过滤跳过，从未执行 ClearBipedPart，旧 partClone 的顶点缓冲仍是旧形变。
- 修法：Custom 先对整个 displaySet 每件护甲的 GetSlotMask().underlying() 取并集 displayMask；forceMorphRebuild 时 rebuildSet 改为 displaySet 全部件，先 ClearSlots(actor, displayMask) 对第一/第三人称一次清空涉及槽位（1.5.11 更正：只清当前 `Custom` 的 `ActorWeightModel`，清两套会把刚重建的另一套清空），再逐件 ApplyArmorAddon；每件后仍按 PAD 开关 RestoreRealItems。非强制路径仍只处理 applySet。
- 诊断：开 Verbose logging 后可见 debug 行 Custom: force-rebuilding N display pieces (mask 0x........) for ........ after a body morph change.；默认日志保持安静。
- 未实机验证：1.5.9 需要 OBody + RaceMenu BodyMorph v4+ 环境（1.5.10 起改为 OBody 4.4.0+ 插件 API 也可），按 docs/TESTING.md §3.22 / §3.23 跑多件/真实穿戴/第一人称用例。

### 4.39 OBody-only 预设刷新（1.5.10）

- 现象：1.5.9 仍复现 OBody 换预设后幻化不刷新；用户环境没有 RaceMenu，日志只有 `MorphRefresh: RaceMenu is not installed; the .tri morph refresh stays off.`，没有任何 `Custom: force-rebuilding`。
- 根因：1.5.9 的 `MorphRefresh` 只有 RaceMenu `BodyMorph` 后端。拿不到 `IBodyMorphInterface` 时 `g_api` 为空，`Tick()` 开头直接 return，`ShouldForceRebuild()` 永远 false；1.5.9 已写好的 displaySet 全量重建分支因此从未被触发。取消幻化/切别的套装会重新走 `Custom` 并重贴，所以看起来“切一下就好”。
- 修法：新增 OBody 插件 API 后端（OBody 4.4.0+）。`kDataLoaded` 时向 receiver `OBody` 发送 `RequestPluginInterface`（`0xc0B0D9cc`，v1），静态 `IOBodyReadinessEventListener` 跟踪 ready；250 ms 轮询 `GetPresetAssignedToActor` 的预设名并混入 FNV 签名；任一后端可用即工作。
- OBody-only 时签名变化先调用 `ApplyOBodyMorphsToActor`，再 `Features::RefreshActor()`；`Custom` 的 2 秒强制窗口按 displaySet 并集 `ClearBipedPart` 后重贴全部显示件。RaceMenu 存在时仍以其 BodyMorph 为权威。
- 日志：`MorphRefresh: OBody plugin API v1 acquired` / `MorphRefresh: OBody is ready` / `MorphRefresh: no body morph provider is available`。
- 未实机验证：OBody API 为按头文件 ABI 手写的最小声明；OBody-only 下 `ApplyOBodyMorphsToActor` 是否同步应用形态未知。按 docs/TESTING.md §3.23 验证。

### 4.40 OBody 换预设后身体与衣服整体消失（1.5.11）

- 现象：幻化带 `.tri` 的服装后，在 OBody 换身体预设，衣服模型与身体模型全部消失，只剩头部与手有模型；按 Z 重新点一次当前套装就恢复。
- 根因：`CustomSkinPlayer::Custom` 每次刷新会被调用两次（第一人称与第三人称各一次）。1.5.9 的 `ClearSlots(actor, displayMask)` 把两套 `BipedAnim` 一起清空，但每次 `Custom` 只把自己的 `actorWeightModel` 重新贴满；第二次调用把第一次刚重建的那套又清掉，于是第三人称的身体与衣服整体消失。
- 修法：`ClearSlots` 改签名 `void ClearSlots(RE::ActorWeightModel* a_model, std::uint32_t a_mask)`，从 `a_model`（实际是 actor 的 `BSTSmartPointer<BipedAnim>` holder 地址）取当前这套 `BipedAnim`，只清它；调用点改 `ClearSlots(actorWeightModel, displayMask)`。displaySet 全量重贴、PAD 诚实还原、NotifyRebuilt 均不变。
- 未实机验证：本机无 Skyrim；按 docs/TESTING.md §3.24 先测第三人称，再切第一人称与第三人称。
- RaceMenu：用户环境已装 RaceMenu 4.0.0（1.5.97），但日志仍是 `Failed to dispatch message to skee`，说明这次运行没有接上 skee 消息监听；不影响 1.5.11 的 OBody 修复，若要用 RaceMenu 后端请先确认 `skse64.log` 里 skee64.dll 加载成功。

### 4.41 OBody 换预设后其余幻化件仍穿模（1.5.12）

- 现象：1.5.11 修好模型整体消失后，OBody 换预设只有带身体参照的 32 槽上衣换了身形；裤子、鞋子、头发、发饰仍是旧模型，出现穿模；取消幻化或切走再切回就正常。
- 根因：OBody NG 的 `ApplyOBodyMorphsToActor` → `ReapplyActorMorphs` → `GenerateBodyByPreset` → `ApplyMorphs` 里，`ApplyBodyMorphs(actor, true)` 是排队生效的；1.5.11 在签名刚变时立刻重建，克隆仍从旧 morph 生成。并且 OBody 会在装备变化后重新派生预设/ORefit，而我们的重建本身就像一次装备变化，所以形态会再变一次。另一个隐患：RaceMenu 在 1.5.97 上 `kDataLoaded` 时可能尚未应答消息交换，1.5.10 只试一次就永久停用 RaceMenu 后端。
- 修法：
  1. `NotifyRebuilt()` 不再要求 RaceMenu —— RaceMenu 或 OBody ready 任一存在就排 150 ms morph pass；OBody-only 走 `ApplyOBodyMorphsToActor`，由 OBody 自己重写所有网格（含克隆）。
  2. 签名变化后除立即 `RefreshActor()` 外，再排一次 **500 ms 延迟重建**（`g_pendingRebuild` / `g_rebuildScheduled` 去重，受 2 秒强制窗口保护）；这次重建再触发一次 morph pass，等 OBody 稳定后克隆才会读到新形态。
  3. 新增 `RetryProviders()`：RaceMenu 接口每 2 秒重试、最多 30 次；成功后切回 RaceMenu 权威路径（`ApplyBodyMorphs(actor,true)`），不再依赖 OBody 重放。
- 日志：`MorphRefresh: queued the body morph pass for <FormID>.`（trace）、`MorphRefresh: rebuilding the illusion of <FormID> after the body morph provider settled.`（debug）。
- 未实机验证：本机无 Skyrim；按 docs/TESTING.md §3.25 复测，重点看裤子/鞋子/头发/发饰是否一起跟随。

### 4.42 手动重穿不刷新 / OBody 仍不跟随（1.5.14）

- 现象（m20054）：1.5.12 实机，OBody 换预设后裤子、鞋子、头发、发饰仍不跟随；按 Z 重新点当前套装没有任何变化。
- 根因一：1.5.12 只有 body morph 签名变化会进全量重建；玩家自己重穿同一套时只有 `OutfitService` 的 revision 变了，`Custom` 仍走 `applySet` 便宜路径，不清槽，`ApplyArmorAddon` 认为槽位已是最新，旧 clone 原样留下。
- 根因二：OBody 的 `ApplyBodyMorphs` 排队生效，并在装备变化后再派生一次形态；500 ms 的一次补建仍可能早于 OBody 落定。
- 修法：
  1. `RevisionRebuildPending(FormID, revision)`：per-actor 记录上次 revision，变化后 2 秒内全量重建（覆盖第三人称 + 第一人称两次调用）。
  2. `MorphRefresh` 两段延迟重建 400 ms / 1400 ms，强制窗口 4 秒。
  3. RaceMenu 重试 5 秒 × 12 次降噪。
  4. 全量重建逐件打印 slot clone 指针，便于判断是否真的换了几何。
- 日志：`Custom: rebuilding <n> display pieces (mask 0x........, outfit revision true/false, body morph true/false) for <FormID>.`、`Custom: <Armor> slot <nn> clone 0x...`、`MorphRefresh: final rebuild of the illusion of <FormID> a second after the body morph change.`
- 未实机验证：本机无 Skyrim；按 docs/TESTING.md §3.26 复测。

## 4.43 1.5.14 幻化循环：换身形后再不穿模

用户 m20054 / m20257 两次复报同一问题。1.5.9–1.5.13 一直在「原槽位清空 + 重贴」上打补丁，方向是错的：

- `OutfitService::set_outfit_c` 等指派类接口从不 `++_revision`，所以按 Z 重穿同一套时 `RevisionRebuildPending` 永远拿到 `false`，1.5.13 的整段逻辑根本没被触发（实机日志 16 次 `Custom` 全为 `outfit revision false`）。
- 即便触发，在同一个 `BIPOBJECT` 上 `ClearBipedPart` + `ApplyArmorAddon` 也只是重填条目，引擎不会为新克隆重新加载 `.tri` 形变目标（日志里 48 条 `slot .. clone 0x0`，此刻 `partClone` 尚未挂上）。

1.5.14 改成自动执行玩家手动验证过的那套动作：

1. 指派类接口补 `++_revision`。
2. `MorphRefresh` 增加「幻化循环」：签名变化或用户重穿同一套时，先清空指派并刷新（幻化摘掉、引擎按真实护甲走一遍），250 ms 后恢复指派并刷新（幻化重新穿上，克隆在形变落定后创建）。
3. 同一角色只排一次循环，`Reset()` 清表。

日志：`MorphRefresh: taking the illusion of ... off for one pass` / `MorphRefresh: illusion of ... restored with a fresh morph target.` / `Custom: rebuilding ... outfit revision true`。

## 4.44 1.5.15 幻化循环去闪烁：同帧完成摘掉与穿回

### 现象与根因

- 1.5.14 用 250 ms 间隔把循环拆成两个主线程任务，中间十几帧渲染的是真实护甲，玩家看到「先还原成原版装备再变回幻化」。
- 那次间隔并非必需：`Features::RefreshActor()` 内部会同步走完 AI 装备流程，日志顺序（`OutfitSystem.cpp:144: Armor Refresh ...` 紧跟 `Patches.cpp: Custom: ...`）证明皮肤钩子就在这次调用里执行。

### 修法

1. `MorphRefresh::RunIllusionCycle(actor, reason)` 顺序执行：`set_outfit_c("")` → `RefreshActor`（引擎按真实护甲走一遍，拿到新克隆）→ `set_outfit_c(name)` → `RefreshActor`，全部在同一个任务内，函数返回时才回到渲染循环。
2. `NGFeatures::AssignOutfit()` 遇到「重穿同一套」直接调用循环并 return，不再先做一次多余的 `RefreshActor`，也不走 250 ms 心跳节流，Z 键即时生效。
3. 心跳轮询发现身形签名变化时同样直接调用循环（先补一次 OBody morph 应用），不再排 250 ms 延迟。
4. 兜底：`[Compatibility] ReillusionGapMs`（0–1000，默认 0）。大于 0 时退化为两段式，间隔由该值决定（会短暂露出原版装备）。

### 日志对照

| 期望顺序（同一帧内） | 说明 |
| --- | --- |
| `MorphRefresh: taking the illusion of <FormID> off for one pass (body morph changed)` | 开始循环 |
| `Patches.cpp: Custom: rebuilding <n> display pieces (... body morph true) for <FormID>.` | 第 1 次刷新（引擎 pass） |
| `MorphRefresh: illusion of <FormID> restored with a fresh morph target.` | 紧接着开始第 2 次刷新 |

### 未验证

本机无 Skyrim，同帧循环的实际显示效果（是否还有 1 帧闪烁、两次刷新的帧耗时）未实机确认；`ReillusionGapMs` 仅作为退路。

## 4.45 幻化栏复制 / 粘贴整套预设（1.5.16）

需求（m20513）：选中一套幻化 → 点复制即把整套预设（名称、槽位规则、单槽位规则、部件）放进剪贴板；点粘贴读取剪贴板，按里面的套装名判断重名 —— 无重名沿用原名新建，有重名加 `_copy` 后缀新建，槽位规则与部件按原 JSON 结构还原；粘贴完成后左侧列表自动焦点到新套装。

### 剪贴板格式

写出去的就是**原版 `OutfitSystemData.json` 里单个 outfit 对象**的结构（1.4.3 起的数字枚举版）：

```json
{
  "name": "束缚巫女服-粉色",
  "isFavorite": true,
  "armors": [
    { "rawFormId": 16777218, "localFormId": 8450, "modName": "Skyrim.esm" }
  ],
  "slotPolicies": { "9": 8 },
  "slotPolicy": 2
}
```

- `slotPolicy` / `slotPolicies` 写数字枚举（0–11、128+），与原版一致；部件带 `modName` + `localFormId`，跨存档/跨机器也能按插件名+本地 ID 解析回来（解析不到再退回 `rawFormId` 查）。
- 粘贴同时接受外面那层 `{"outfits":[...]}`（取数组第一项），所以从 `OutfitSystemData.json` 里剪一段、或从别的玩家那里拿到的片段都能直接粘。

### 实现

| 位置 | 内容 |
| --- | --- |
| `src/cpp/include/OutfitClipboard.h` / `src/cpp/OutfitClipboard.cpp` | `Copy(name)` 组装 JSON 并用 Win32 剪贴板 API（`CF_UNICODETEXT`，UTF-16）写出；`Paste(createdName)` 读回文本、解析、解析部件与策略、算免重名、调用 store 创建 |
| `OutfitService::create_outfit_preset()` | 一次加锁内建好整套：先按「无覆盖」重置 32 槽 + 基础策略，再套用 JSON 里的基础策略与单槽覆盖，最后插部件 —— 缺字段不会继承构造函数默认值（这与导入 `OutfitSystemData.json` 的处理一致） |
| `MenuUI` 底部 | `Copy` / `Paste` 两个按钮（`Create empty` 之后），复制/粘贴结果全部走 HUD 提示；粘贴成功后 `FocusOutfitInList()` 选中新套装、翻到它所在页，行渲染时 `SetScrollHereY(0.5)` 把它滚到视野中间 |

重名规则：`名字` → 被占则 `名字_copy` → 再占则 `名字_copy2`、`名字_copy3`…（最多尝试 100 次，超长名字按 UTF-8 边界截断后再拼后缀）。

### 日志与提示

- `Outfits: copied 'X' to the clipboard (N bytes of JSON).`
- `Outfits: pasted 'base' as 'name_copy' (N pieces, blanket XXOO, M slot overrides).`
- HUD：`Outfit copied to the clipboard.` / `Pasted outfit 'name_copy'.`；失败分别是「剪贴板里没有文本」「其他程序正在占用剪贴板」「内容不是有效 JSON」「里面不是幻化数据」。

### 未验证

本机无 Skyrim：两个按钮的实际点击、剪贴板读写、粘贴后列表焦点与滚动都是静态实现，未实机验证；按 `docs/TESTING.md` §3.29 复测。

## 4.46 SLIF NG 膨胀框架兼容（1.5.17）

需求（m20732）：SLIF NG（BodyInflationNG.dll，github.com/crajjjj/SLIFNG，Nexus 192276）改变身形时，幻化件要跟着一起变形；不能像 OBody 那样靠「一换预设就整轮重建」的笨办法。

### 为什么原来完全没反应

| 环节 | 事实 |
| --- | --- |
| SLIF 的输出 | 经 RaceMenu skee 写两样东西：BodySlide morph（`SetMorph` + `ApplyBodyMorphs`）与骨架节点缩放（`AddNodeTransformScale` + `UpdateNodeTransforms`），全部挂在 key `SexLab Inflation Framework.esp` 下 |
| 我们的信号 | 只有两路：RaceMenu `BodyMorph` 的 `VisitMorphValues` 签名、OBody 的 `GetPresetAssignedToActor` 预设名签名 |
| 断点 | 用户环境（1.5.97 + RaceMenu 4.0.0）里 `Dispatch(0x9E3779B9, ..., "skee")` 一直失败，日志每 5 秒一条 `Failed to dispatch message to skee`；morph 签名从未工作，SLIF 改滑块我们看不到 |
| 为什么名字会 miss | SKSE 2.1.2+ 把 receiver 名解析成「注册了消息监听器的插件」列表下标，任何一个 DLL 加载失败都会让后面的名字整体错位；skee64 自己用 `RegisterListener(nullptr)` 收所有 sender |

### 三条修法

1. **skee / OBody 握手加无名广播**：命名 dispatch 没拿到时就再发一次 receiver = `nullptr` 的广播（SLIF NG 的 `SKEE::GetInterfaceMap()` 用同一手法，作者注释也写明 1.5.97 上 RaceMenu 会晚答）。
2. **SLIF NG 直连后端**：`GetModuleHandleA("BodyInflationNG.dll")` → `GetProcAddress("SLIFNG_GetQueryInterface")` → `IQueryInterface1*`。每 250 ms 对每个已幻化 actor：`IsTracked` 为真时读 4 个规范键的 `GetApplied`（1.0 中性；ramp 中是 in-flight 值），四点混进签名。因为它是**纯 C 导出**，不经过 SKSE 消息，不受名字错位影响；0.4.17 及更老的版本没有这个导出，退回 `0x534C4946 'SLIF'` 消息握手。
3. **签名去抖**：签名静置 250 ms 才触发幻化循环，同一角色两次循环至少隔 600 ms。膨胀是连续值（SLIF ramp、OBody 分步写），逐值重建会把画面刷爆；去抖后一次膨胀只重建一次，ramp 落定后再补一轮。

### 现在覆盖到的形变来源

| 来源 | 信号 |
| --- | --- |
| SLIF NG 膨胀（morph 路径） | SLIF 的 `GetApplied` + RaceMenu morph 签名 |
| SLIF NG 膨胀（节点缩放路径） | SLIF 的 `GetApplied` |
| OBody / OBody NG 换预设 | 预设名签名（+ `ApplyOBodyMorphsToActor` 重放） |
| RaceMenu 手动改 Body Morph 滑块 | RaceMenu morph 签名 |
| 其它写 skee morph 的 mod | RaceMenu morph 签名 |

### 日志

- `MorphRefresh: SLIF NG query interface v2 acquired (N tracked actors); inflation changes will rebuild the illusion.`
- `MorphRefresh: SLIF NG is not installed; inflation changes are not watched directly (the morph signature still covers them).`
- 变化触发时仍是 1.5.14/1.5.15 那一对：`taking the illusion of <FormID> off for one pass` → `illusion of <FormID> restored with a fresh morph target.`

### 未验证

本机无 Skyrim：SLIF 接口的 vtable 顺序按 `SLIFNG_API.h` 抄写（`Version / IsTracked / TrackedActorCount / GetValue / GetMinValue / GetMaxValue / GetApplied / GetCombinedMorph / GetCalculationType / IsIncrementalInflation`），广播兜底与去抖均未实机验证。按 `docs/TESTING.md` §3.30 复测。

## 5. 静态验证

| 项 | 结果 |
| --- | --- |
| 编译 | BUILD_EXIT=0，0 error / 0 warning（1.5.17 增量重编；`--parallel 1` 规避页面文件不足导致的 C1076） |
| 版本资源 | `FileVersion = 1.5.17.0` / `ProductVersion = 1.5.17.0` / `FileDescription` / `ProductName` = `Skyrim Outfit System NG` / `LegalCopyright` = `MIT License`（`src/cpp/include/version.h` + `src/cpp/version.rc`，1.4.2 起把 .rc 显式加入 target_sources；此前 glob 只收 .cpp，资源从未编入）。PowerShell `(Get-Item <dll>).VersionInfo` 实测四项均有值 |
| 导入表 | 仅 KERNEL32 / USER32 / ole32 / VERSION / SHELL32 |
| 延迟导入 | 目录 RVA = 0、size = 0（无延迟导入项） |
| 导出 | SKSEPlugin_Load / SKSEPlugin_Query / SKSEPlugin_Version 均存在 |
| 独立加载 | 空目录 `LoadLibraryExW(path, 0, 0)` 返回句柄且 `GetProcAddress` 取到 `SKSEPlugin_Load` / `SKSEPlugin_Query` |
| 1.5.14 关键字符串 | `Custom: rebuilding ` / `slot {:02} clone ` / `outfit revision ` / `MorphRefresh: final rebuild of the illusion of` 可检索 |
| 1.5.15 关键字符串 | `MorphRefresh: taking the illusion of` / `restored with a fresh morph target` / `ReillusionGapMs` / `CycleIllusion` 均可检索；`FileVersion = 1.5.15.0` |
| 1.5.16 关键字符串 | `Outfits: copied ` / `Outfits: pasted ` / `The clipboard does not contain valid JSON.` / `Could not create the pasted outfit.` 可检索；`FileVersion = 1.5.16.0` |
| 1.5.17 关键字符串 | `SLIF NG query interface v` / `SLIFNG_GetQueryInterface` / `BodyInflationNG.dll` / `SLIF NG is not installed` / `inflation changes will rebuild the illusion` 均可检索；`FileVersion = 1.5.17.0`；导入表仍只有 KERNEL32 / USER32 / ole32 / VERSION / SHELL32 |
| 1.5.12 关键字符串 | `MorphRefresh: queued the body morph pass` / `MorphRefresh: rebuilding the illusion of` / `RaceMenu did not answer the interface exchange` / `MorphRefresh: OBody plugin API v1 acquired` 可检索；`Custom: force-rebuilding` / `display pieces` 仍保留 |
| 1.5.11 关键字符串 | `MorphRefresh: OBody plugin API v1 acquired` / `MorphRefresh: OBody is ready` / `MorphRefresh: no body morph provider` / `GetPresetAssignedToActor` 可检索；`Custom: force-rebuilding` / `display pieces` / `after a body morph change` 仍保留 |
| 关键字符串 | `Menu: raw gamepad input enabled` / `RegisterInpoutEvent` / `RegisterInputEvent` / `input-event export` / `Menu: SKSE Menu Framework` /  `Advanced Nudity Detection` / `PAD compatibility` / `PAD slot report` / `Log slot report` / `Outfit editor:` / `Replace the conflicting pieces` / `Menu: sections registered` / `Trampoline ready` / `Skinning hooks applied` / `translation lines read` / `AutoSwitch: native location` / `<random>` / `State random: actor` / `Outfits: deleted` / `DynamicHDT` / `SceneOutfits: SexLab / OStim scene detection installed` / 可选 `ig*`（`igIsKeyDown_Nil`、`igSetNextWindowPos`、`igGetMainViewport`、`igCalcTextSize`、`igGetWindowPos`、`igGetWindowSize`、`igSetScrollHereY_Float`）均在；`###SOSQuickPicker`、`Quick picker: opening at`、`optional entry point` 可检索；UTF-8 `语言`、`快速选择`、`取消幻化` 可检索 |
| Papyrus | 6 个脚本 papyrus.exe compile 全部 status=0；SkyrimOutfitSystemNativeFuncs.pex 与 SkyOutSysQuickslotEffect.pex 已入包 |
| 函数数量 | OutfitSystem.cpp 注册 66 个原生函数，与 psc 里 66 条 Global Native 声明一致（1.3.0 未改 Papyrus 端） |
| 翻译文件 | `interface/translations/SkyrimOutfitSystemNG_english.txt`（29,016 字节）与 `_chinese.txt`（21,530 字节），UTF-16LE+BOM，各 248 条 `$英文<TAB>译文`；槽位条目已换成 30–61 那套名字（`$Amulet<TAB>项链`、`$Unnamed (probably Face)<TAB>未知 (一般来说是 面部)`），1.5.16 追加复制/粘贴 11 条，用脚本回读校验 248/248 条 |
| JSON 策略 | `PolicyToInt()` 与 `PolicyFromInt()` 互逆：0–11 与 128+ 区间全覆盖，其它值返回空；导出样例 `"slotPolicy": 2` / `"slotPolicies": {"9": 8}` 与 `兼容参考/OutfitSystemData.json` 一致 |
| 包内哈希 | SHA256SUMS.txt 逐文件列出并复核（30 个文件 + SHA256SUMS.txt） |

## 6. 首次实机建议顺序

0. 确认 SKSE64 与 Address Library 与游戏版本匹配，能进主菜单。
1. 装本包，进游戏看 `Documents/My Games/<game>/SKSE/SkyrimOutfitSystemNG.log`：`Trampoline ready`、五条 `... patched.`、`Menu: sections registered`、以及 `Compatibility: Advanced Nudity Detection ... detected`（装了 AND 时）。
2. 读旧存档：`Migrating a vN record` → `Migrated co-save vN` → `Post-load: hooks resumed` → `Player 3D is ready`。
3. 菜单建套装 → 应用 → 外观变化；换同槽真实护甲，外观仍是套装件。
4. **AND**：穿上完整护甲应用幻化 → 用 AND 自己的状态显示（或 Papyrus `AND_ModEventListener.GetNude(player)`）确认是“有穿”；把套装换成**空套装** → 应变成裸体/上身空/下身空。日志开 `ExtraLogging` 可看到 `AND compatibility: ... rank 1.`。
5. **PAD（1.4.0 重点）**：先点 Settings → Mod compatibility → **Log slot report**，逐槽确认 `shown 'X' | real 'Y'`；`real '<none>'` 的槽位 PAD 摸不到（裸槽贴件，预期）。然后穿真实护甲 + 幻化，挨打 → 幻化外观应出现破损，PAD 的 Tracked armors 页出现条目。仍不可撕时做对照：`[Compatibility] ProceduralArmorDamage = off` 重启，同样操作若表现一致，说明不在还原路径，请附日志反馈。
6. Ctrl+Shift+L 打开快速选择窗口：**首次**居中 640×800、焦点落在当前套装；拖动/缩放后关闭，重启游戏再打开应回到上次的位置与尺寸（`[UI] QuickPickerX/Y/Width/Height`）；`W/S`/`↑↓`/手柄十字上下选择、`A/D`/`←→`/十字左右翻页（按住加速）、`E`/`Enter`/手柄 A 穿上并关窗、`R`/手柄 Y 随机、`Esc`/手柄 B 关闭；底部 `Remove outfit` 恢复真实外观。详见 `docs/TESTING.md` §3.9。
7. 施放 “Change Outfit” 法术：默认弹出快速选择窗口；菜单 Settings → Random outfit 勾选随机后再施放应直接随机。
8. 存档 → 读档：套装与指派都在；AND 阵营状态在读档后仍然是幻化的结果（心跳会在 1 秒内补写）。
9. **语言**：Settings → Language 选“中文”。若 SMF 有中文字体（`[Fonts] EnableChinese = true` 且 `Data/SKSE/Plugins/Fonts/CN.ttf` 存在），界面立刻变中文；否则保持英文并在日志写 `Language: Chinese was requested but ...`。改 `Data\interface\translations\SkyrimOutfitSystemNG_chinese.txt` 后点 **Reload the language files** 应立即生效（左侧树节点需重启）。
10. **导入导出**：Settings → Outfit data → **Export outfits to OutfitSystemData.json**，确认 `Data\SKSE\Plugins\OutfitSystemData.json` 的键是 `enabled` / `outfits` / `actorOutfitAssignments`（原版结构）；删一个套装再 **Import** 应恢复。
11. **老存档策略**：用 v4 旧存档读档，检查原本设成 `XXXO`（需要已装备）的套装没有变成 `XXOO`（始终使用套装）。
12. **快选窗口（1.4.2 重点）**：按 Z（快捷槽能力/热键）打开 —— 标题应是“天际幻化系统 - 快速选择”而不是 “Debug”；窗口应在屏幕居中，拖动 + 缩放后关闭、重启游戏再打开应回到上次的位置与尺寸；直接改 `[UI] QuickPickerX/Y/Width/Height` 后重启也应生效。日志有 `Quick picker: opening at ...`。
13. **快选长按**：按住 `S`/`↓`/手柄十字下，约 0.2 秒就应开始连续下移（不必按住一秒）。
14. **JSON 往返（1.4.3 重点）**：Export 后确认 `slotPolicy` / `slotPolicies` 写的是**数字**（`"slotPolicy": 2`、`"slotPolicies": {"9": 8}`），与老的 `OutfitSystemData.json` 完全同格式；再 Import 回同一份文件，套装的槽位策略必须原样保留（`需要已装备` 仍是 `需要已装备`，不能变成“从不显示任何东西”）。**最直接的一条**：用 `兼容参考/OutfitSystemData.json`（530 套）覆盖 `Data/SKSE/Plugins/OutfitSystemData.json` 后点 Import，日志应打印 `Imported 530 outfits and 2 actor assignments`，随便挑几套看基础策略都是“需要已装备（槽位有装备时才显示幻化）”。
15. **槽位编号（1.4.3 修正）**：套装编辑器的槽位列表应显示 `头部（槽位 30）`、`头发, 短（槽位 31）`、`项链（槽位 35）`、`盾牌（槽位 39）`、`未知 (一般来说是 面部)（槽位 44）`、`FX（槽位 61）`。
16. **措辞**：中文下策略项应显示“始终使用幻化”“只有幻化时显示幻化”，不再出现“始终使用套装”。
17. 按 `docs/TESTING.md` §3 跑功能矩阵（1.4.3 新增用例在 §3.12，1.4.4 新增在 §3.13）。
18. **删除按钮（1.4.4）**：Outfits 左列表选一套 → Delete → 出现确认条 → Delete；套装从列表消失，日志 `Outfits: deleted '...': yes.`；该套装原本指派给某个 actor/状态，也应一并清掉。
19. **横向滚动（1.4.4）**：套装编辑器里找一条名字很长的槽位行，槽位列表与逐槽策略面板都应能横向滚动，行尾按钮不被文字挡住。
20. **日志分级（1.4.4）**：默认日志只应有生命周期行；勾选 Settings → Diagnostics 的 Verbose logging 重启后，才会出现 Settings/ImGuiApi/Hooks 的逐项诊断行。
21. **原生自动切换（1.4.4）**：让 NPC/玩家换地点，外观应在事件后立即切换（不再等 10 秒）；日志（Verbose）有 `AutoSwitch: ... switched to state N.`；Papyrus.0.log 不应再有 `SetOutfitUsingStateForAllConfiguredActors` 的周期调用。
22. **状态随机（1.4.4）**：给某状态选 `<随机>` → 立刻抽一套并显示；离开该状态再回来应换一套；同一状态内反复触发战斗事件不应反复更换。

23. **列表按钮（1.5.0）**：Outfits 左列表点任意一行的 **Wear**，应当立刻换上并刷新外观；点 **Delete** 应弹出确认条，不再需要“瞄准边缘”。短名字与超长名字各试一次，按钮位置都不应压住文字或跑到窗口外。
24. **快选手柄（1.5.0）**：用手柄十字键在快速选择窗口上下移动，屏幕里只应有一个高亮；按 A 只换装并关窗，不应同时触发 `Remove outfit`；按 B 只关窗。
25. **SMP 重置（1.5.0）**：装 Faster HDT-SMP 后，Settings → Mod compatibility 应显示 `Faster HDT-SMP (DynamicHDT): detected`；勾选 Reset SMP physics，穿带物理的幻化 → 换另一套带物理的套装，目标角色的裙摆/头发物理应重新初始化（不会残留上一套的骨骼状态）。同屏其他 NPC 不应被重置。未装 FSMP 时该行显示 not detected，勾选也不报错。
26. **场景套装（1.5.0）**：建两套 `测试服装` 与 `测试服装_sex`，给玩家穿上前者；勾选 SceneOutfitSwitching；进入 OStim / SexLab 场景 → 应自动换成 `测试服装_sex`；结束 → 应恢复 `测试服装`。再测：当前套装本身叫 `X_sex` → 进入场景不变；只有 `测试服装`、没有 `_sex` 版本 → 进入场景保持原套装。开 Verbose logging 可看 `SceneOutfits: ...` 行。
27. **线程与边角（1.5.2）**：按 `docs/TESTING.md` §3.16 的 A–E 跑：菜单内连续翻页、文本框内按热键、OStim/SexLab 重叠、删除当前过滤套装、关闭菜单后页大小落盘、编辑器列表缓存。
28. **边界与状态（1.5.3）**：按 `docs/TESTING.md` §3.17 的 A–E 跑：Papyrus 删除/覆盖当前套装立即刷新、只配状态套装也能战斗/死亡切换、仅收藏唯一项时随机仍有反应、坏 JSON/坏 co-save 不崩、金件幻化与重复换装不崩。
29. **手柄导航（1.5.4）**：按 `docs/TESTING.md` §3.18 的 A–C 跑：快选窗打开时 SMF 主菜单仍可用手柄、快选窗只移动列表高亮、按 A 不触发 Remove outfit、关闭后主菜单仍可用；无 `_sex` 套装时日志打印期望名字。
30. **SMF 版本（1.5.6）**：先用 SMF 3.18+（3.18 或 3.23 均可）跑 `docs/TESTING.md` §3.19 A；若手上有 3.9，再跑 §3.19 B 验证 raw fallback。日志先确认 `Menu: SKSE Menu Framework 3.18 ...`（或你的实际版本）与是否有 `raw gamepad input enabled`。
31. **X 键（1.5.7）**：打开快速选择窗口，按键盘 X → 幻化取消、HUD 提示“已取消幻化”；按手柄 X → 行为一致；搜索框输入 X 不触发；Remove outfit 按钮行为一致。见 §3.20 A。
32. **`.tri` 刷新（1.5.7）**：幻化一套带 `.tri` 的服装（OBody 身形），在 OBody 换预设、RaceMenu 改 Body Morph 滑块 → 不穿脱、不取消幻化，模型约 1 秒内刷新；日志有 `MorphRefresh: the body morphs of ... changed; rebuilding the illusion.`；第一/第三人称都正确。见 §3.20 B。
33. **身体槽位移除（1.5.8）**：选中一套有多件护甲的套装，滚到右侧 Body slots，点任意一行的“移除” → 该行上方立刻出现确认提示，同一行出现“移除 / 取消”；再点“移除”该件消失，日志有 `Outfit editor: removed ...`；点“取消”则保留。用超长护甲名再试一次，按钮应始终在可视区内。见 §3.21。
34. **OBody 多件刷新（1.5.9/1.5.10）**：幻化一套带 `.tri` 的上衣 + 裤子（其中至少一件是真实穿戴），在 OBody 换身体预设 → 上衣与裤子一起按新身形刷新，不再只有 32 槽上衣变化、裤子穿模；第一/第三人称都正确。开 Verbose logging 应看到 `MorphRefresh: OBody plugin API v1 acquired`、`MorphRefresh: OBody is ready` 与 `Custom: force-rebuilding ... display pieces ...`。见 §3.22 / §3.23。
35. **OBody-only 刷新（1.5.10 重点）**：确认 `Data/SKSE/Plugins` 里没有 RaceMenu；只装 OBody 4.4.0+。幻化一套带 `.tri` 的服装，在 OBody 里换预设 → 约 1 秒内整套幻化件按新身形刷新；取消幻化/重进游戏再试一次。日志不应再出现 `RaceMenu is not installed`（改为 `OBody plugin API v1 acquired`）。见 §3.23。

36. **OBody 换预设后模型消失（1.5.11 重点）**：幻化一套带 `.tri` 的服装 → 在 OBody 换身体预设 → 第三人称身体与衣服应完整（不再只剩头手）；再切第一/第三人称确认两套 biped 都完整。开 Verbose logging 应看到两条 `Custom: force-rebuilding ...`（第一/第三人称各一条）。见 §3.24。

37. **OBody 其余幻化件跟随（1.5.12 重点）**：幻化一套带 `.tri` 的上衣 + 裤子 + 鞋子（至少一件真实穿戴），在 OBody 换预设 → 约 1 秒内**全部**幻化件按新身形刷新，不再只有上衣变化、其余穿模；切第一/第三人称再确认。开 Verbose logging 应看到 `MorphRefresh: rebuilding the illusion of ... after the body morph provider settled.`。见 §3.25。

38. **手动重穿与 OBody 全部件跟随（1.5.14 重点）**：幻化一套带 `.tri` 的衣服，OBody 换一个明显不同的预设 → 按 Z（或快选窗选中当前套装按 E）重穿当前套装 → 幻化件立刻按新身形重建，不再需要「取消幻化再切回」。开 Verbose logging 应看到 `Custom: rebuilding ... outfit revision true`，以及每件护甲的 `Custom: <Armor> slot .. clone 0x...`；两次重建之间同一槽位的 clone 指针应变化。见 §3.26。
39. **幻化循环无可见闪烁（1.5.15 重点）**：幻化带 `.tri` 的衣服后 OBody 换预设，观察画面**不应**出现原版装备；日志里 `taking the illusion ... off for one pass` 与 `illusion of ... restored` 应在同一帧、成对出现。若仍能看到原版装备一闪，把 `[Compatibility] ReillusionGapMs` 设为 20 试一次（会短暂露出，属预期），并在回报里注明。见 §3.28。

40. **复制 / 粘贴整套预设（1.5.16 重点）**：在 Outfits 左列表选一套（名字高亮）→ 点底部 **Copy** → HUD 提示已复制，日志 `Outfits: copied ...`；点 **Paste** → 新套装出现在列表里并被自动选中、滚动到视野中间；因为原名已存在，新名字应是 `<原名>_copy`。再粘一次应得到 `<原名>_copy2`。把粘贴出来的那套打开套装编辑器，**基础策略与单槽位规则必须与源套装完全一致**（例如源是「需要已装备」+ 盾牌「穿透」，粘贴件也要一样）。也可用记事本打开 `OutfitSystemData.json`，复制其中一个 outfit 对象（或整个 `{"outfits":[...]}`）到剪贴板再 Paste，应同样能建出套装。见 §3.29。
41. **SLIF NG 膨胀跟随（1.5.17 重点）**：装 SLIF NG 0.4.18+，幻化一套带 `.tri` 的衣服（例如 SLIF 的 belly 目标经 body profile 映射到 BodySlide 滑块的那种），用 SLIF 的调试法术/控制台给该 actor 加膨胀 → 幻化件应随身体一起鼓起来，不再穿模；停止膨胀/瘦身后同样跟随。日志先确认 `MorphRefresh: SLIF NG query interface v2 acquired`，再看每次变化成对出现 `taking the illusion ... off for one pass` 与 `illusion of ... restored with a fresh morph target`；连续 ramp 时最多每 600 ms 重建一次，不应刷屏。见 §3.30。

## 7. 已知限制
- SMP 重置依赖 Faster HDT-SMP 的 Papyrus 静态函数 `DynamicHDT.ResetPhysics`；没装 FSMP 时开关无效但不报错。
- SexLab / OStim 场景套装只对玩家生效（事件不带参与者列表；OStim 的 NPC 子线程不处理）。

- 本机没有 Skyrim；除用户已实测的 PAD、快速选择窗口位置记忆、**SMF 3.9→3.18/3.23 手柄恢复**外，其余游戏内行为未经实机验证（静态层面只证明：DLL 能被 SKSE 加载、无外部 DLL 依赖、钩子站点能找到、脚本能编译）。
- 快速选择窗口的手柄依赖 SKSE Menu Framework ≥ 3.18（3.18 与 3.23 均已实测）；3.9 可用 1.5.6 的 raw fallback，但该路径未实机验证，优先升级框架。
- AND 兼容是**近似判定**：只看槽位掩码，不做关键词级精判；只写裸体/上身/下身三个阵营，不写 `AND_Showing*` 与谦逊度（Modesty）系列。
- AND 会周期性重扫真实装备覆盖等级，我们靠“刷新即同步 + 1 秒心跳”追平；极端情况下（AND 在同一帧内重扫且玩家不再有任何输入）可能出现短暂不一致。
- PAD 仍无法撕“幻化件下**完全没有**真实护甲”的槽位（PAD 只认背包里真实穿着且场景里存在的护甲）；1.4.0 已修复有真实护甲打底的那种情况（§4.10）。
- 引擎内部对话 / 台词条件（TESCondition）读真实装备的 `ExtraWorn` 标记，不受幻化影响；想影响它们只能针对具体 mod 的公开接口做兼容（AND 就是这样做的）。
- 直接调用 `Actor.GetWornArmor` / `GetInventory` 的第三方 DLL 仍看到真实护甲（CommonLibSSE-NG 里是内联实现，无单一入口）。
- 随机换装只有键盘组合键；全局手柄组合键未实现（快速选择窗口内部已可全手柄操作）。
- 翻译文件只覆盖界面文案与 HUD；左侧树节点标题由菜单框架缓存，改语言需重启游戏。
- VR 未构建。
- 1.5.7 的 `.tri` 实时刷新与快选窗 X 键未实机验证；RaceMenu `BodyMorph` 接口为手写最小 ABI 声明。
- 1.5.8 的身体槽位行内移除确认尚未实机验证。
- 1.5.9 的 OBody 多件刷新尚未实机验证；1.5.10 起不再要求 RaceMenu，但需要 **OBody 4.4.0+** 的插件 API，且该 API 为按头文件 ABI 手写的最小声明。
- 1.5.10 的 OBody 预设轮询尚未实机验证；OBody-only 路径下 `ApplyOBodyMorphsToActor` 是否同步应用形态未知。
- 1.5.11 的 OBody 换预设后身体/衣服消失修复尚未实机验证；修复前提仍是 OBody 4.4.0+ 的插件 API。
- 1.5.12 的 500 ms 延迟二次重建与 RaceMenu 重试尚未实机验证；OBody 端 `ApplyOBodyMorphsToActor` 仍是手写 ABI 声明。
- 1.5.14 的 revision 触发全量重建、400/1400 ms 两段延迟重建与 clone 指针诊断均未实机验证。
- 1.5.15 的同帧循环未实机验证；若某些机型上同帧刷新仍拿到旧形变，需把 `ReillusionGapMs` 调到 20–50（代价是短暂露出原版装备）。
- 1.5.17 的 SLIF NG 兼容未实机验证；SLIF 查询接口是手写最小 ABI（按 `SLIFNG_API.h` 抄的 vtable 顺序），广播兜底与签名去抖也未实机验证。SLIF NG 0.4.17 及更老版本只有消息握手、没有 `SLIFNG_GetQueryInterface` 导出。
- 1.5.16 的复制 / 粘贴未实机验证；剪贴板读写是 Win32 `CF_UNICODETEXT`，其它程序正占用剪贴板时会提示「请重试」。粘贴解析的是原版 JSON 结构，`modName` + `localFormId` 解析不到时退回 `rawFormId`（跨 load order 可能指向别的护甲）。

## 8. 排查速查

| 日志 | 含义 / 处置 |
| --- | --- |
| `Language: Chinese was requested but` | 想用中文但菜单框架没有 CJK 字形：在 `Data/SKSE/Plugins/SKSEMenuFramework.ini` 开 `[Fonts] EnableChinese = true` 并放入 `Fonts/CN.ttf`（或把 `PrimaryFont` 指向已有的中文字体）。插件不会注入字体。 |
| `PAD slot report: slot` | Log slot report 的输出。`real '<none>'` = 该槽没有真实护甲，PAD 无处记损伤。 |
| `Compatibility: Advanced Nudity Detection ... detected; nudity, topless and bottomless ranks now follow the displayed outfit.` | AND 兼容已生效 |
| `... was found, but its nudity factions are missing` | AND 装了但阵营 EditorID 找不到（可能是 AND 改版），兼容自动退回原版行为 |
| `PAD compatibility: ... without a real armour underneath` | 该幻化件下面**没有**真实护甲，PAD 撕不到（设计如此，只能靠真实护甲打底） |
| `Language: wrote the editable translation files to` | 首次运行（目录里一个语言文件都没有）自动写出 english / chinese 两份模板到 `Data\interface\translations` |
| `Language: N language file(s), M lines in total, from ...` | 找到 N 个语言文件、合计 M 条有效翻译行；语言下拉里就会列 N 种 |
| `Language: interface language 'xx' (mode '...'), N translated lines.` | 最终生效的语言与实际覆盖条数 |
| `Imported N outfits and M actor assignments from OutfitSystemData.json.` | JSON 导入成功（N 套装、M 个 actor 赋值）；用 `兼容参考/OutfitSystemData.json` 应得到 `Imported 530 outfits and 2 actor assignments` |
| `OutfitSystemData.json: the policy 'X' is unknown; it is ignored.` | 文件里出现 0–11 / 128+ 之外的策略值：该字段被忽略（槽位回落基础策略），套装不受影响 |
| `Menu: the framework did not create a standalone window` | 菜单框架没给快速选择窗口开独立窗口（版本过旧或 `AddWindow` 失败），快捷窗退化为菜单内一页 |
| `ImGuiApi: N/M optional helpers resolved ... window geometry tracked/not tracked` | 逐符号绑定的结果。小于 M/M 时上面几行会各有一条 `optional entry point ... is missing`，只影响对应小功能 |
| `address library id N is missing` | 该运行时缺 ID，对应钩子被跳过；查 Hooks.cpp 的 ID 对 |
| `unexpected opcode 0xXX at +0xNN` | 站点被别的 mod 改过，钩子跳过（不崩） |
| `Trampoline ready ... (0 bytes free)` | 空间耗尽，后面的钩子会跳过 |
| `MorphRefresh: RaceMenu BodyMorph vN acquired` | 已接上 RaceMenu BodyMorph v4+，`.tri` 形变会跟随刷新 |
| `MorphRefresh: OBody plugin API v1 acquired` | 已接上 OBody 4.4.0+ 插件 API；换预设会触发整套幻化重建 |
| `MorphRefresh: SLIF NG query interface v2 acquired` | 已接上 SLIF NG（0.4.18+）的只读查询接口；膨胀/瘦身会触发幻化重建 |
| `MorphRefresh: SLIF NG is not installed` | 没装 SLIF NG，或版本老到既没有该导出、消息握手也没应答；不影响 RaceMenu / OBody 两条信号 |
| `Failed to dispatch message to skee` | 命名通道没找到 skee 的监听器（SKSE 名字错位或 skee 注册晚）。1.5.17 起失败后会立刻再发一次无名广播；随后若出现 `RaceMenu BodyMorph vN acquired` 说明兜底成功 |
| `MorphRefresh: OBody is ready; preset changes will rebuild the illusion.` | OBody 已就绪，预设轮询开始工作 |
| `MorphRefresh: no body morph provider is available` | RaceMenu 与 OBody 都没有可用接口：`.tri` 刷新停用，其余功能正常 |
| `MorphRefresh: the body morphs of <FormID> changed; rebuilding the illusion.` | 检测到该 actor 的 morph 签名变化，已排队强制重建幻化槽 |
| `MorphRefresh: rebuilding the illusion of <FormID> after the body morph provider settled.`（debug） | 1.5.12 的 500 ms 二次重建已触发；看到它说明 OBody 已稳定后再重建，若仍穿模请附这一行前后的全部日志。 |
| `MorphRefresh: queued the body morph pass for <FormID>.`（trace） | 1.5.12 起重建后不再只对 RaceMenu 排 morph pass；OBody-only 也会排。 |
| `RaceMenu did not answer the interface exchange` | 1.5.12 起只是 info，会在 2 秒后最多重试 30 次；若最终接上会再打 `RaceMenu BodyMorph vN acquired`。 |
| `MorphRefresh: RaceMenu BodyMorph ...`（info/warn，未取得） | 没装 RaceMenu 或版本低于 4；若同时装了 OBody 4.4.0+，仍会使用 OBody 后端 |
| `Menu: SKSE Menu Framework <版本> (api <n>)` | 框架版本；低于 3.18 时手柄可能无法进入自定义窗口，优先升级框架 |
| `Menu: raw gamepad input enabled for the quick picker (framework < 3.18).` | 旧框架下已启用 1.5.6 的原始手柄兜底 |
| `Menu: SKSE Menu Framework <版本> handles gamepad input for the quick picker.` | 3.18+ 使用框架自身的 gamepad 翻译，未注册 raw 回调 |
| `Menu: SKSE Menu Framework not found` | 没装菜单框架，其它功能正常，但没有菜单与快速选择窗口 |
| Papyrus.0.log: `Cannot open store for class "SkyrimOutfitSystemNativeFuncs"` | Scripts 目录缺 pex，重装整包 |
| `The player never finished loading its 3D` | 600 帧内玩家 3D 未就绪，刷新被跳过；手动刷新或重进 |
| `ImGuiApi: optional entry point ... is missing` | 菜单框架没导出某个可选 ImGui 函数：只影响对应小功能（如滚动定位），窗口照常打开；把日志里的符号名发来即可加备选名。 |
| `ImGuiApi: the window entry points are incomplete` | 四个开窗函数缺失，快速选择窗口无法自绘：属于框架版本不匹配，装 SKSE Menu Framework 3.x。 |
| `Quick picker: opening at ... (centred)` | 当前 ini 里 `QuickPickerX/Y` 还是 `-1`（首次或从未拖动过）。 |
| `Outfits: deleted 'X': yes.` | 删除按钮生效（1.4.4）。`no` 说明名字已不存在，可能被其它途径删掉了。 |
| `Outfit editor: removed 'X' from 'Y'.` | 身体槽位列表的行内“移除”确认成功（1.5.8）；没有这行说明只点了第一次、还在确认状态。 |
| `Outfits: copied 'X' to the clipboard (N bytes of JSON).` | Copy 按钮成功（1.5.16）；HUD 同时提示。 |
| `Outfits: could not write 'X' to the clipboard.` | 剪贴板被别的程序占用或打开失败；稍后重试即可，不影响其它功能。 |
| `Outfits: pasted 'A' as 'A_copy' (N pieces, blanket XXOO, M slot overrides).` | Paste 成功（1.5.16）；名字带 `_copy` 说明原名已被占用。部件数与策略覆盖数可用来核对是否与源套装一致。 |
| `Custom: force-rebuilding N display pieces (mask 0x........) for ........ after a body morph change.`（debug） | 1.5.9/1.5.10 的整套幻化重建已触发；默认日志看不到，需在 Settings 勾选 Verbose logging。 |
| `AutoSwitch: native location and fast travel detection installed.` | 原生自动切换已注册（1.4.4）；没这行说明 `ScriptEventSourceHolder` 取不到，地点切换不会自动发生。 |
| `AutoSwitch: 00000014 switched to state 3.`（debug） | 状态真的变了才打；默认级别看不到，开 Verbose logging 才有。 |
| `State random: actor 00000014 entered state 3 and rolls 'X'.`（debug） | `<random>` 抽中了哪一套；同状态内重复触发战斗不应重复出现。 |

| `SceneOutfits: SexLab / OStim scene detection installed.` | 场景套装监听已注册（1.5.0）；没有这行说明 `ModCallbackEvent` 源取不到。 |
| `SceneOutfits: ... scene started; 'A' -> 'A_sex'.` | 场景开始并已换上 `_sex` 套装（debug，需 Verbose logging）。 |
| `SceneOutfits: no 'A_sex' outfit for the ... scene; the current outfit is kept.` | 没有同名 `_sex` 套装，按设计保持当前幻化。 |
| `SMP: Faster HDT-SMP (DynamicHDT) is not installed; the physics reset is skipped.` | 开关打开但没装 FSMP；只提示一次，不影响换装（debug）。 |
| `SMP: DynamicHDT.ResetPhysics could not be dispatched for ...` | FSMP 存在但静态调用失败，检查 FSMP 版本/ Papyrus 注册（debug）。 |
| `Custom: rebuilding <n> display pieces (mask 0x…, outfit revision …, body morph …) for <FormID>.`（debug） | 1.5.14 起每次全量重建都打印；`outfit revision true` 表示这次由「套装被重新指派/编辑」触发（Z 键、快选窗 E、Papyrus SetOutfit），`body morph true` 表示由身形变化触发。 |
| `Custom: <ArmorFormID> slot <nn> clone 0x…`（debug） | 1.5.14 诊断：同一槽位两次重建后 clone 指针应变化；不变说明 `ApplyArmorAddon` 复用了旧几何，问题不在 morph 时序。 |
| `MorphRefresh: taking the illusion of <FormID> off for one pass (<原因>)`（debug） | 1.5.15 起循环两阶段在同一帧完成；<原因> 为 `body morph changed`（身形变化）或 `the outfit was re-applied`（Z / 快选窗 E）。 |
| `MorphRefresh: illusion of <FormID> restored with a fresh morph target.`（debug） | 紧随上一条；两条之间不应大量出现其它日志（说明没有跨帧）。 |
| `[Compatibility] ReillusionGapMs`（ini） | 默认 0 = 同帧循环；>0 时退化为两段式，会短暂露出原版装备。 |
| `MorphRefresh: final rebuild of the illusion of <FormID> a second after the body morph change.`（debug） | 1.5.14 的 1400 ms 第二段重建已触发（第一段是 `after the body morph provider settled`）。 |

## 9. 维护提示

- 游戏版本升级：只改 `src/cpp/hooking/Hooks.cpp` 的 `REL::RelocationID` 参数与 `SiteOffset`，其它逻辑不动。
- 新增 Papyrus 函数：`OutfitSystem.cpp` 注册 + `src/papyrus/skyrimoutfitsystemnativefuncs.psc` 声明 + 重新编译 pex 入包 + `docs/PAPYRUS_API.md` 表格。
- **兼容第三方 mod 一律走数据契约**：优先找对方“已经对外的结果”（阵营、全局变量、Papyrus getter、JSON 配置），不要去 hook 对方函数或写它的内存。这样对方升级不换契约就仍然兼容。
- 新增 Papyrus 脚本时记得同步 dist/Scripts：漏一个 pex 就会让整类原生函数失效（1.0.1 的教训）。
- 任何跨线程访问 OutfitService 都必须先取守卫；守卫的析构必须解锁。
- 新增界面文案：在 `I18n.cpp` 的 `kDictionary` 加一条（并重跑生成脚本，更新 `Data/interface/translations/SkyrimOutfitSystemNG_english.txt` 与 `_chinese.txt` 两份 233 条模板），否则外置文件里缺少该键、只能回退英文。
- 翻译文件解析规则：**TAB 优先、`=` 兜底**（键里可以带 `=`），所以生成脚本必须写 TAB 而不是 `=`。
- 槽位编号：菜单里显示的是 CK 号 = `BIPED_OBJECT` 索引 + `kDisplaySlotOffset`（30）；日志与内部数据仍用 0 基索引，改文案时不要把两者混用。
- 策略序列化：`OutfitSystemData.json` 必须写数字 id（`PolicyToInt`），字符串码只用于导入兼容；新增策略时同时更新 `kPolicies`、`PolicyFromInt` 的逆映射与词典文案。
- `MenuUI` 里调用新增的 `ig*` 之前先看 `ImGuiApi::Api::Extras` 有没有：可选绑定缺失时不能让菜单整块失效。
